package com.cg.ibs.investment.ui;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Scanner;

import org.apache.log4j.Logger;

import com.cg.ibs.investment.bean.AccountBean;
import com.cg.ibs.investment.bean.BankMutualFund;
import com.cg.ibs.investment.bean.InvestmentTransaction;
import com.cg.ibs.investment.bean.MutualFund;
import com.cg.ibs.investment.exception.IBSException;
import com.cg.ibs.investment.service.BankService;
import com.cg.ibs.investment.service.BankServiceImpl;
import com.cg.ibs.investment.service.CustomerService;
import com.cg.ibs.investment.service.CustomerServiceImpl;

public class InvestmentUI {
	static Scanner sc;
	static int status = 3;
	static Logger log = Logger.getLogger(InvestmentUI.class.getName());

	// Declaring objects of Client Service and Bank Service
	CustomerService service = new CustomerServiceImpl();
	BankService bankservice = new BankServiceImpl();

	// Method to start the program
	public void doIt() {
		InvestmentUI investmentUI = new InvestmentUI();
		while (status == 3) {
			System.out.println("	Press 1 for customer and 2 for bank representative");
			System.out.println("----------------------------------------------------------");
			boolean check = true;
			String temp = sc.next();
			while (check) {

				if (temp.matches("[0-9]")) {
					status = Integer.parseInt(temp);
					check = false;
				} else {
					System.out.println("Please Re-enter");
					temp = sc.next();
				}
			}

			Menu choice = null;
			BankMenu option = null;

			BankService bankservice = new BankServiceImpl();

			// Options for the Customer
			if (status == 1) {
				System.out.println("Enter the userId");
				String userId = sc.next();
				System.out.println("Enter the password");
				String password = sc.next();
				boolean check1 = true;

				while (check1) {
					try {
						if (service.validateCustomer(userId, password)) {
							while (choice != Menu.QUIT) {
								System.out.println("Choice");
								System.out.println("--------------------");
								for (Menu menu : Menu.values()) {
									System.out.println(menu.ordinal() + 1 + "\t" + menu.toString().replace("_", " "));
								}
								boolean check2 = true;
								int ordinal = 0;
								String temp1 = sc.next();
								while (check2) {

									if (temp1.matches("[0-9]+")) {
										ordinal = Integer.parseInt(temp1);
										check2 = false;
									} else {
										System.out.println("Please Re-enter");
										temp1 = sc.next();
									}
								}

								// int ordinal = sc.nextInt();
								if (ordinal >= 1 && ordinal <= Menu.values().length) {
									choice = Menu.values()[ordinal - 1];

									switch (choice) {
									case VIEW_MY_INVESTMENT:
										investmentUI.viewMyInvestments(userId);

										break;

									case VIEW_GOLD_PRICE:
										try {
											System.out.println("Gold price is Rs. " + service.viewGoldPrice());
										} catch (IBSException e) {

										}

										break;
									case VIEW_SILVER_PRICE:
										System.out.println("Silver price is Rs. " + service.viewSilverPrice());
										break;
									case VIEW_MF_PLANS:
										investmentUI.viewMFPlans();
										break;
									case BUY_GOLD:
										investmentUI.buyGold(userId);
										break;
									case SELL_GOLD:
										investmentUI.sellGold(userId);
										break;
									case BUY_SILVER:
										investmentUI.buySilver(userId);
										break;
									case SELL_SILVER:
										investmentUI.sellSilver(userId);
										break;
									case INVEST_MF_PLAN:
										investmentUI.investMFPlan(userId);
										break;
									case WITHDRAW_MF_PLAN:
										investmentUI.withdrawMFPlan(userId);
										break;
									case VIEW_MY_TRANSACTIONS:
										investmentUI.viewMyTransactions(userId);
										break;
									case LINK_NEW_ACCOUNT:
										investmentUI.linkAccount(userId);
										break;
									case QUIT:

										System.out.println("You are successfully logged out");
										break;

									}

								} else {
									System.out.println("Invalid Option");

								}

							}
							check1 = false;

						} else {
							System.out.println("Invalid Username Or Password");
							System.out.println("Enter the userId");
							userId = sc.next();
							System.out.println("Enter the password");
							password = sc.next();
						}
					} catch (IBSException e) {
						log.error(e);
						System.out.println(e.getMessage());
					}
				}
				System.out.println("Press 3 to continue, any other number to EXIT");
				boolean check10 = true;
				String temp10 = sc.next();
				while (check10) {

					if (temp10.matches("[0-9]")) {
						status = Integer.parseInt(temp10);
						check10 = false;
					} else {
						System.out.println("Please Re-enter");
						temp10 = sc.next();
					}
				}

			}
			// Options for the Bank Representative
			else if (status == 2) {
				System.out.println("Enter the userId");
				String userId = sc.next();
				System.out.println("Enter the password");
				String password = sc.next();
				boolean check1 = true;

				while (check1) {
					try {
						if (bankservice.validateBank(userId, password)) {
							while (option != BankMenu.QUIT) {
								System.out.println("Choice");
								System.out.println("--------------------");
								for (BankMenu menu : BankMenu.values()) {
									System.out.println(menu.ordinal() + 1 + "\t" + menu.toString().replace("_", " "));
								}
								boolean check2 = true;
								int ordinal = 0;
								String temp1 = sc.next();
								while (check2) {

									if (temp1.matches("[0-9]+")) {
										ordinal = Integer.parseInt(temp1);
										check2 = false;
									} else {
										System.out.println("Please Re-enter");
										temp1 = sc.next();
									}
								}

								// int ordinal = sc.nextInt();
								if (ordinal >= 1 && ordinal <= BankMenu.values().length) {
									option = BankMenu.values()[ordinal - 1];

									switch (option) {
									case UPDATE_GOLD_PRICE:
										investmentUI.updateGoldPrice();
										break;
									case UPDATE_SILVER_PRICE:
										investmentUI.updateSiverPrice();
										break;
									case ADD_MUTUALFUND_PLAN:
										investmentUI.addMFPlans();
										break;
									case UPDATE_NAV:
										investmentUI.updateNav();
										break;

									case QUIT:
										System.out.println("You are successfully logged out");

										break;

									}

								} else {
									System.out.println("Invalid Option");

								}

							}
							check1 = false;

						} else {
							System.out.println("Invalid Username Or Password");
							System.out.println("Enter the userId");
							userId = sc.next();
							System.out.println("Enter the password");
							password = sc.next();
						}
					} catch (IBSException e) {
						log.error(e);
						System.out.println(e.getMessage());
					}
				}
				System.out.println("Press 3 to continue, any other number to EXIT");
				boolean check11 = true;
				String temp11 = sc.next();
				while (check11) {

					if (temp11.matches("[0-9]")) {
						status = Integer.parseInt(temp11);
						check11 = false;
					} else {
						System.out.println("Please Re-enter");
						temp11 = sc.next();
					}
				}
			} else {
				System.out.println("Please enter valid choice");
				System.out.println("Press 3 to continue");
				boolean check12 = true;
				String temp12 = sc.next();
				while (check12) {

					if (temp12.matches("[0-9]")) {
						status = Integer.parseInt(temp12);
						check12 = false;
					} else {
						System.out.println("Please Re-enter");
						temp12 = sc.next();
					}
				}
			}
		}

	}

	public void updateNav() {

		boolean check = true;
		try {

			String format = "%1$-20s%2$-20s%3$-20s\n";
			String string = "ID";
			String string2 = "Title";
			String string3 = "NAV(INR)";
			System.out.println("----------------------------------------------------");
			System.out.format(format, string, string2, string3);
			System.out.println("----------------------------------------------------");

			for (Entry<Integer, BankMutualFund> entry : service.viewMFPlans().entrySet()) {

				System.out.format(format, entry.getValue().getMfPlanId(), entry.getValue().getTitle(),
						entry.getValue().getNav());
			}

			System.out.println("Enter the plan Id you want to choose");
			int mfPlanId = 0;
			String temp = sc.next();
			while (check) {
				if (temp.matches("[0-9]{1,10}")) {
					mfPlanId = Integer.parseInt(temp);

					if (service.viewMFPlans().containsKey(mfPlanId)) {

						check = false;
					} else {
						System.out.println("Please enter correct planId");
						temp = sc.next();
					}
				} else {
					System.out.println("Please enter valid planId");
					temp = sc.next();

				}
			}
			System.out.println("Enter nav value");
			String navTemp = sc.next();
			double nav = 0;
			boolean check1 = true;
			while (check1) {
				if (navTemp.matches("[+]?[0-9]*\\.?[0-9]+")) {
					nav = Double.parseDouble(navTemp);
					if (nav > 0) {
						check1 = false;
					} else {
						System.out.println("Please enter the valid NAV");
						navTemp = sc.next();
					}
				} else {
					System.out.println("Please Re-enter the value");
					navTemp = sc.next();
				}

			}
			bankservice.updateNav(mfPlanId, nav);

			System.out.println("transaction completed");
			log.info("user withdraws from mutual fund");
		} catch (IBSException exp) {
			log.error(exp);
			System.out.println(exp.getMessage());
		}

	}

	// Customer views his/her Investments
	public void viewMyInvestments(String userId) {
		try {

			System.out.println("UCI" + " " + service.viewInvestments(userId).getUCI());
			System.out.println("GoldUnits(grams): " + " " + service.viewInvestments(userId).getGoldunits());
			System.out.println("SilverUnits(grams): " + " " + service.viewInvestments(userId).getSilverunits());
			System.out.println("Balance(INR): " + " "
					+ service.viewInvestments(userId).getAccount().getBalance().setScale(2, BigDecimal.ROUND_DOWN));

			List<MutualFund> InvstmntList = new ArrayList<>(service.viewInvestments(userId).getFunds());
			List<MutualFund> ActiveinvstmntList = new ArrayList<>();
			List<MutualFund> closedinvstmntList = new ArrayList<>();
			for (int i = 0; i < InvstmntList.size(); i++) {
				if (InvstmntList.get(i).getClosingDate() == null) {
					ActiveinvstmntList.add(InvstmntList.get(i));

				} else {
					closedinvstmntList.add(InvstmntList.get(i));
				}

			}

			DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/YYYY");
			String format = "%1$-20s%2$-20s%3$-20s%4$-20s%5$-20s%6$-20s\n";

			String string = "MfId";
			String string1 = "Title";
			String string2 = "NAV";
			String string3 = "Mf Units";
			String string4 = "Opening Date";
			String string5 = "Closing Date";
			String string6 = "NA";

			System.out.println(
					"-----------------------------------------------------------------------------------------------------------------");
			System.out.format(format, string, string1, string2, string3, string4, string5);
			System.out.println(
					"-----------------------------------------------------------------------------------------------------------------");
			for (int i = 0; i < ActiveinvstmntList.size(); i++) {
				MutualFund temp = ActiveinvstmntList.get(i);

				System.out.format(format, temp.getFolioNumber(), temp.getBankMutualFund().getTitle(),
						service.viewMFPlans().get(temp.getBankMutualFund().getMfPlanId()).getNav(),
						Math.round(temp.getMfUnits()*100.00)/100.00, formatter.format(temp.getOpeningDate()), string6);

			}

			for (int i = 0; i < closedinvstmntList.size(); i++) {
				MutualFund temp = closedinvstmntList.get(i);
				System.out.format(format, temp.getFolioNumber(), temp.getBankMutualFund().getTitle(),
						service.viewMFPlans().get(temp.getBankMutualFund().getMfPlanId()).getNav(),
						Math.round(temp.getMfUnits() * 100.00)/ 100.00, formatter.format(temp.getOpeningDate()),
						formatter.format(temp.getClosingDate()));

			}
			log.info("Investments viewed successfully");
		} catch (IBSException exp) {
			log.error(exp);
			System.out.println(exp.getMessage());
		}

	}

	// Customer sells his/her gold
	public void sellGold(String userId) {
		boolean success = true;
		System.out.println("Enter number of gold units to sell(in grams):");
		String goldUnits = sc.next();
		double GoldUnits = 0;

		try {
			while (success) {
				if (goldUnits.matches("[+]?[0-9]*\\.?[0-9]+")) {
					GoldUnits = Double.parseDouble(goldUnits);
					if (GoldUnits > 0) {

						success = false;
					} else {
						System.out.println("Please  Re-enter the value");
						goldUnits = sc.next();
					}

				} else {

					System.out.println("Please  Re-enter the value");
					goldUnits = sc.next();

				}
			}

			service.sellGold(GoldUnits, userId);
			System.out.println("transaction completed");
			log.info("User sells gold");
		} catch (IBSException e) {
			log.error(e);
			System.out.println(e.getMessage());
		}
	}

	// Customer buys gold
	public void buyGold(String userId) {
		boolean success = true;
		System.out.println("Enter number of gold units to buy(in grams):");
		String goldUnits = sc.next();
		double GoldUnits = 0;

		try {
			while (success) {
				if (goldUnits.matches("[+]?[0-9]*\\.?[0-9]+")) {
					GoldUnits = Double.parseDouble(goldUnits);
					if (GoldUnits > 0) {

						success = false;
					} else {
						System.out.println("Please  Re-enter the value");
						goldUnits = sc.next();
					}
				} else {

					System.out.println("Please  Re-enter the value");
					goldUnits = sc.next();

				}
			}

			service.buyGold(GoldUnits, userId);
			System.out.println("transaction completed");
			log.info("User buys gold");
		} catch (IBSException e) {
			log.error(e);
			System.out.println(e.getMessage());
		}
	}

	// Customer sells his/her Silver
	public void sellSilver(String userId) {
		boolean success = true;
		System.out.println("Enter number of silver units to sell(in grams):");
		String goldUnits = sc.next();
		double GoldUnits = 0;

		try {
			while (success) {
				if (goldUnits.matches("[+]?[0-9]*\\.?[0-9]+")) {
					GoldUnits = Double.parseDouble(goldUnits);
					if (GoldUnits > 0) {

						success = false;
					} else {
						System.out.println("Please  Re-enter the value");
						goldUnits = sc.next();
					}
				} else {

					System.out.println("Please  Re-enter the value");
					goldUnits = sc.next();

				}
			}

			service.sellSilver(GoldUnits, userId);
			System.out.println("transaction completed");
			log.info("User sells silver");
		} catch (IBSException e) {
			log.error(e);
			System.out.println(e.getMessage());
		}

	}

	// Customer views available Mutual Fund plans
	public void viewMFPlans() {
		String format = "%1$-20s%2$-20s%3$-20s\n";
		String string = "ID";
		String string2 = "Title";
		String string3 = "NAV(INR)";
		System.out.println("----------------------------------------------------");
		System.out.format(format, string, string2, string3);
		System.out.println("----------------------------------------------------");
		try {
			for (Entry<Integer, BankMutualFund> entry : service.viewMFPlans().entrySet()) {

				System.out.format(format, entry.getValue().getMfPlanId(), entry.getValue().getTitle(),
						entry.getValue().getNav());
			}
			log.info("User views Mutual fund offerd by bank");
		} catch (IBSException e) {
			log.error(e);
			System.out.println(e.getMessage());
		}

	}

	// Customer buys Silver
	public void buySilver(String userId) {
		boolean success = true;
		System.out.println("Enter number of silver units to buy(in grams):");
		String goldUnits = sc.next();
		double GoldUnits = 0;

		try {
			while (success) {
				if (goldUnits.matches("[+]?[0-9]*\\.?[0-9]+")) {
					GoldUnits = Double.parseDouble(goldUnits);
					if (GoldUnits > 0) {

						success = false;
					} else {
						System.out.println("Please  Re-enter the value");
						goldUnits = sc.next();
					}
				} else {

					System.out.println("Please  Re-enter the value");
					goldUnits = sc.next();

				}
			}

			service.buySilver(GoldUnits, userId);
			System.out.println("transaction completed");
			log.info("user buys silver");
		} catch (IBSException e) {
			log.error(e);
			System.out.println(e.getMessage());
		}
	}

	// Customer invests in a Mutual Fund
	public void investMFPlan(String userId) {

		String format = "%1$-20s%2$-20s%3$-20s\n";
		String string = "ID";
		String string2 = "Title";
		String string3 = "NAV(INR)";
		System.out.println("----------------------------------------------------");
		System.out.format(format, string, string2, string3);
		System.out.println("----------------------------------------------------");
		try {
			for (Entry<Integer, BankMutualFund> entry : service.viewMFPlans().entrySet()) {

				System.out.format(format, entry.getValue().getMfPlanId(), entry.getValue().getTitle(),
						entry.getValue().getNav());
			}

		} catch (IBSException e) {
			log.error(e);
			System.out.println(e.getMessage());
		}

		try {
			int mfId = 0;
			boolean check = true;
			boolean check1 = true;
			double mfAmount = 0;
			System.out.println("Enter the mutual fund Id:");
			String temp = sc.next();
			while (check) {

				if (temp.matches("[1-9][0-9]{2,10}")) {

					mfId = Integer.parseInt(temp);
					if (service.viewMFPlans().containsKey(mfId)) {

						check = false;
					} else {
						System.out.println("Please enter valid MfId");
						temp = sc.nextLine();

					}

				}

				else {
					System.out.println("Please Re-enter the value");
					temp = sc.next();

				}

			}

			System.out.println("Enter the amount to invest");
			temp = sc.next();
			while (check1) {
				if (temp.matches("[+]?[0-9]*\\.?[0-9]+")) {
					mfAmount = Double.parseDouble(temp);
					if (mfAmount > 0) {
						check1 = false;
					} else {
						System.out.println("Please Re-enter the value");
						temp = sc.nextLine();

					}

				} else {
					System.out.println("Please Re-enter the value");
					temp = sc.next();

				}

			}

			service.investMF(mfAmount, userId, mfId);
			System.out.println("transaction completed");
			log.info("User invests in mutual fund");
		} catch (IBSException e) {
			log.error(e);
			System.out.println(e.getMessage());

		}
	}

	// Customer withdraws from a Mutual Fund
	public void withdrawMFPlan(String userId) {
		List<MutualFund> InvestmentList;
		MutualFund mutualFund = null;
		boolean check = true;
		try {
			Map<Integer, Integer> SerialNumber = new HashMap();
			int k = 1;
			InvestmentList = new ArrayList<>(service.viewInvestments(userId).getFunds());
			List<MutualFund> openinvestmentList = new ArrayList<>();
			for (int i = 0; i < InvestmentList.size(); i++) {
				if (InvestmentList.get(i).getClosingDate() == null) {

					openinvestmentList.add(InvestmentList.get(i));
				}

			}
			if (openinvestmentList.size() > 0) {

				DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/YYYY");
				String format = "%1$-20s%2$-20s%3$-20s%4$-20s%5$-20s%6$-20s\n";

				String string = "MfId";
				String string1 = "Title";
				String string2 = "NAV";
				String string3 = "Mf Units";
				String string4 = "Opening Date";
				String string5 = "Sr.No";

				System.out.println(
						"-----------------------------------------------------------------------------------------------------------------");
				System.out.format(format, string5, string, string1, string2, string3, string4);
				System.out.println(
						"-----------------------------------------------------------------------------------------------------------------");
				for (int i = 0; i < InvestmentList.size(); i++) {
					if (InvestmentList.get(i).getClosingDate() == null) {
						SerialNumber.put(k, i);
						MutualFund temp = InvestmentList.get(i);

						System.out.format(format, k, temp.getFolioNumber(), temp.getBankMutualFund().getTitle(),
								temp.getBankMutualFund().getNav(), (Math.round(temp.getMfUnits() * 100)) / 100,
								formatter.format(temp.getOpeningDate()));

						k++;
					}

				}
				System.out.println("Enter the plan number you want to choose");
				String temp = sc.next();
				while (check) {
					if (temp.matches("[0-9]{1,2}")) {
						int index = Integer.parseInt(temp);
						if (index <= InvestmentList.size() && index >= 0) {
							if (SerialNumber.get(index) != null) {
								mutualFund = InvestmentList.get(SerialNumber.get(index));

								if (mutualFund != null) {
									service.withdrawMF(userId, mutualFund);
									check = false;
								} else {
									System.out.println("Please Re-enter the index of the plan");
									temp = sc.next();

								}
							} else {
								System.out.println("Please Re-enter the index of the plan");
								temp = sc.next();

							}
						} else {
							System.out.println("Please Re-enter the index of the plan");
							temp = sc.next();
						}
					} else {
						System.out.println("Please enter valid index of the plan");
						temp = sc.next();

					}
				}

				System.out.println("transaction completed");
			} else {
				System.out.println("Sorry!! you have to buy new plans");
			}
			log.info("user withdraws from mutual fund");
		} catch (IBSException exp) {
			log.error(exp);
			System.out.println(exp.getMessage());
		}

	}

	// Bank representative updates gold price
	public void updateGoldPrice() {
		boolean success = true;
		System.out.println("Enter the updated gold price");
		String goldPrice = sc.next();
		double GoldPrice = 0;
		try {
			while (success) {
				if (goldPrice.matches("[+]?[0-9]*\\.?[0-9]+")) {
					GoldPrice = Double.parseDouble(goldPrice);
					if (GoldPrice > 0) {

						success = false;
					} else {
						System.out.println("Please  Re-enter the value");
						goldPrice = sc.next();
					}
				} else {

					System.out.println("Please  Re-enter the value");
					goldPrice = sc.next();

				}
			}

			if (bankservice.updateGoldPrice(GoldPrice)) {
				System.out.println("Gold Price updated successfully");
			} else {
				System.out.println("Already updated");
			}
			log.info("Bank updates Gold Price");
		} catch (IBSException e) {
			log.error(e);
			System.out.println(e.getMessage());
		}
	}

	// Bank representative updates Silver price
	public void updateSiverPrice() {
		boolean success = true;
		System.out.println("Enter the updated silver price");
		String silverPrice = sc.next();
		double SilverPrice = 0;
		try {
			while (success) {
				if (silverPrice.matches("[+]?[0-9]*\\.?[0-9]+")) {
					SilverPrice = Double.parseDouble(silverPrice);
					if (SilverPrice > 0) {

						success = false;
					} else {
						System.out.println("Please  Re-enter the value");
						silverPrice = sc.next();
					}
				} else {

					System.out.println("Please  Re-enter the value");
					silverPrice = sc.next();

				}
			}

			if (bankservice.updateSilverPrice(SilverPrice)) {
				System.out.println("Silver Price updated successfully");
			} else {
				System.out.println("Already updated");
			}

			log.info("Bank updates silver price");
		} catch (IBSException e) {
			log.error(e);
			System.out.println(e.getMessage());
		}
	}

	// Bank representative adds Mutual Fund plans
	public void addMFPlans() {
		boolean check = true;
		System.out.println("Enter mutualfundId");
		String temp = sc.next();
		int mfId = 0;
		while (check) {

			if (temp.matches("[1-9][0-9]{2,10}")) {

				mfId = Integer.parseInt(temp);
				try {
					if (service.viewMFPlans().containsKey(mfId) == false) {

						check = false;
					} else {
						System.out.println("MF Id already exists.");
						temp = sc.nextLine();

					}

				} catch (IBSException e) {
					log.error(e);
					System.out.println(e.getMessage());
				}

			}

			else {
				System.out.println("Please Re-enter the value");
				temp = sc.next();

			}

		}

		boolean check1 = true;
		System.out.println("Enter mutualfundtitle");
		String title = sc.next();

		System.out.println("Enter nav value");
		String navTemp = sc.next();
		double nav = 0;
		while (check1) {
			if (navTemp.matches("[+]?[0-9]*\\.?[0-9]+")) {
				nav = Double.parseDouble(navTemp);
				if (nav > 0) {
					check1 = false;
				} else {
					System.out.println("Please enter the valid NAV");
					navTemp = sc.next();
				}
			} else {
				System.out.println("Please Re-enter the value");
				navTemp = sc.next();
			}

		}

		try {
			BankMutualFund MF = new BankMutualFund();
			MF.setTitle(title);
			MF.setMfPlanId(mfId);
			MF.setNav(nav);

			bankservice.addMF(MF);
			System.out.println("Mutual Fund plans updated successfully");
			log.info("Bank adds Mutual Fund");
		} catch (IBSException e) {
			log.error(e);
			System.out.println(e.getMessage());
		}

	}

	public void viewMyTransactions(String userId) {
		try {

			DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/YYYY hh:mm");
			String format = "%1$-10s%2$-20s%3$-35s%4$-20s%5$-20s%6$-20s\n";

			String string = "TransId";
			String string1 = "TransDate";
			String string2 = "Description";
			String string3 = "Amount(INR)";
			String string4 = "Type";
			String string5 = "Units";
			String string6 = "PricePerUnit/NAV(INR)";

			System.out.println(
					"-------------------------------------------------------------------------------------------------------------------");
			System.out.format(format, string, string1, string2, string3, string4, string5, string6);
			System.out.println(
					"-------------------------------------------------------------------------------------------------------------------");

			List<InvestmentTransaction> tsBeans = service.getTransactions(userId);
			for (InvestmentTransaction t : tsBeans) {

				System.out.format(format, t.getTransactionId(), formatter.format(t.getTransactionDate()),
						t.getTransactionDescription(), t.getTransactionAmount().setScale(2, BigDecimal.ROUND_DOWN),
						t.getTransactionType(), Math.round(t.getUnits() * 100.00) / 100.00, t.getPricePerUnit());
			}

			log.info("User views transaction");
		} catch (IBSException e) {
			log.error(e);
			System.out.println(e.getMessage());
		}

	}

	public void linkAccount(String userId) {
		try {
			int i = 1;
			boolean check = true;
			for (AccountBean a : service.getAccountList(userId)) {
				System.out.println(
						i + "\t\t" + a.getAccNo() + "\t\t" + a.getBalance().setScale(2, BigDecimal.ROUND_DOWN));
				i++;
			}
			System.out.println("Choose the account number you want to link");

			String temp = sc.next();
			int a = 0;
			while (check) {
				if (temp.matches("[0-9]{1,2}")) {
					a = Integer.parseInt(temp);
					if (a <= service.getAccountList(userId).size() && a > 0) {
						check = false;
					} else {
						System.out.println("Please Re-enter the choice");
						temp = sc.next();

					}

				} else {

					System.out.println("Please Re-enter the choice");
					temp = sc.next();

				}
			}

			BigInteger accountNumber = service.getAccountList(userId).get(a - 1).getAccNo();
			System.out.println("You have chosen the account---" + accountNumber.toString());
			service.linkMyAccount(accountNumber, userId);
		} catch (IBSException e) {
			System.out.println(e.getMessage());

		}

	}

	// Main Method
	public static void main(String[] args) {
		sc = new Scanner(System.in);
		InvestmentUI investmentUI = new InvestmentUI();
		investmentUI.doIt();
		System.out.println("The program has ended");
		sc.close();

	}
}