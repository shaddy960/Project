package com.cg.ibs.investment.bean;

public enum AccountStatus {
OPEN, CLOSED
}
