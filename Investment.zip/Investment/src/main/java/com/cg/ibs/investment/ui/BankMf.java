package com.cg.ibs.investment.ui;

public enum BankMf {
	ADD,UPDATE,REMOVE,GO_BACK

}
