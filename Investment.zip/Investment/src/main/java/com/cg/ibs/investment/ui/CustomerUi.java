package com.cg.ibs.investment.ui;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Scanner;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.stereotype.Component;

import com.cg.ibs.investment.bean.AccountBean;
import com.cg.ibs.investment.bean.BankMutualFund;
import com.cg.ibs.investment.bean.InvestmentTransaction;
import com.cg.ibs.investment.bean.MutualFund;
import com.cg.ibs.investment.exception.IBSException;
import com.cg.ibs.investment.service.BankService;
import com.cg.ibs.investment.service.BankServiceImpl;
import com.cg.ibs.investment.service.CustomerService;
import com.cg.ibs.investment.service.CustomerServiceImpl;
@Component
public class CustomerUi {
	static Scanner sc=new Scanner(System.in);
	//static int status = 3;
	static Logger log = Logger.getLogger(InvestmentUI.class.getName());
	


	// Declaring objects of Client Service and Bank Service
	/*CustomerService service = new CustomerServiceImpl();
	BankService bankservice = new BankServiceImpl();
	*/
	@Autowired
	CustomerService service ;
	@Autowired
	BankService bankservice ;
	
	// Customer views his/her Investments
		public void viewMyInvestments(String userId) {
			try {

				System.out.println("UCI" + " " + service.viewInvestments(userId).getUCI());
				System.out.println("GoldUnits(grams): " + " " + service.viewInvestments(userId).getGoldunits());
				System.out.println("SilverUnits(grams): " + " " + service.viewInvestments(userId).getSilverunits());
				System.out.println("Balance(INR): " + " "
						+ service.viewInvestments(userId).getAccount().getBalance().setScale(2, BigDecimal.ROUND_DOWN));

				List<MutualFund> InvstmntList = new ArrayList<>(service.viewInvestments(userId).getFunds());
				List<MutualFund> ActiveinvstmntList = new ArrayList<>();
				List<MutualFund> closedinvstmntList = new ArrayList<>();
				for (int i = 0; i < InvstmntList.size(); i++) {
					if (InvstmntList.get(i).getClosingDate() == null) {
						ActiveinvstmntList.add(InvstmntList.get(i));

					} else {
						closedinvstmntList.add(InvstmntList.get(i));
					}

				}

				DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/YYYY");
				String format = "%1$-20s%2$-20s%3$-20s%4$-20s%5$-20s%6$-20s\n";

				String string = "MfId";
				String string1 = "Title";
				String string2 = "NAV";
				String string3 = "Mf Units";
				String string4 = "Opening Date";
				String string5 = "Closing Date";
				String string6 = "NA";

				System.out.println(
						"-----------------------------------------------------------------------------------------------------------------");
				System.out.format(format, string, string1, string2, string3, string4, string5);
				System.out.println(
						"-----------------------------------------------------------------------------------------------------------------");
				for (int i = 0; i < ActiveinvstmntList.size(); i++) {
					MutualFund temp = ActiveinvstmntList.get(i);

					System.out.format(format, temp.getFolioNumber(), temp.getBankMutualFund().getTitle(),
							service.viewMFPlans().get(temp.getBankMutualFund().getMfPlanId()).getNav(),
							Math.round(temp.getMfUnits()*100.00)/100.00, formatter.format(temp.getOpeningDate()), string6);

				}

				for (int i = 0; i < closedinvstmntList.size(); i++) {
					MutualFund temp = closedinvstmntList.get(i);
					System.out.format(format, temp.getFolioNumber(), temp.getBankMutualFund().getTitle(),
							service.viewMFPlans().get(temp.getBankMutualFund().getMfPlanId()).getNav(),
							Math.round(temp.getMfUnits() * 100.00)/ 100.00, formatter.format(temp.getOpeningDate()),
							formatter.format(temp.getClosingDate()));

				}
				log.info("Investments viewed successfully");
			} catch (IBSException exp) {
				log.error(exp);
				System.out.println(exp.getMessage());
			}

		}
		// Customer sells his/her gold
		public void sellGold(String userId) {
			boolean success = true;
			System.out.println("Enter number of gold units to sell(in grams):");
			String goldUnits = sc.next();
			double GoldUnits = 0;

			try {
				while (success) {
					if (goldUnits.matches("[+]?[0-9]*\\.?[0-9]+")) {
						GoldUnits = Double.parseDouble(goldUnits);
						if (GoldUnits > 0) {

							success = false;
						} else {
							System.out.println("Please  Re-enter the value");
							goldUnits = sc.next();
						}

					} else {

						System.out.println("Please  Re-enter the value");
						goldUnits = sc.next();

					}
				}

				service.sellGold(GoldUnits, userId);
				System.out.println("transaction completed");
				log.info("User sells gold");
			} catch (IBSException e) {
				log.error(e);
				System.out.println(e.getMessage());
			}
		}
		// Customer buys gold
		public void buyGold(String userId) {
			boolean success = true;
			System.out.println("Enter number of gold units to buy(in grams):");
			String goldUnits = sc.next();
			double GoldUnits = 0;

			try {
				while (success) {
					if (goldUnits.matches("[+]?[0-9]*\\.?[0-9]+")) {
						GoldUnits = Double.parseDouble(goldUnits);
						if (GoldUnits > 0) {

							success = false;
						} else {
							System.out.println("Please  Re-enter the value");
							goldUnits = sc.next();
						}
					} else {

						System.out.println("Please  Re-enter the value");
						goldUnits = sc.next();

					}
				}

				service.buyGold(GoldUnits, userId);
				System.out.println("transaction completed");
				log.info("User buys gold");
			} catch (IBSException e) {
				log.error(e);
				System.out.println(e.getMessage());
			}
		}

		// Customer sells his/her Silver
		public void sellSilver(String userId) {
			boolean success = true;
			System.out.println("Enter number of silver units to sell(in grams):");
			String goldUnits = sc.next();
			double GoldUnits = 0;

			try {
				while (success) {
					if (goldUnits.matches("[+]?[0-9]*\\.?[0-9]+")) {
						GoldUnits = Double.parseDouble(goldUnits);
						if (GoldUnits > 0) {

							success = false;
						} else {
							System.out.println("Please  Re-enter the value");
							goldUnits = sc.next();
						}
					} else {

						System.out.println("Please  Re-enter the value");
						goldUnits = sc.next();

					}
				}

				service.sellSilver(GoldUnits, userId);
				System.out.println("transaction completed");
				log.info("User sells silver");
			} catch (IBSException e) {
				log.error(e);
				System.out.println(e.getMessage());
			}

		}

		// Customer views available Mutual Fund plans
		public void viewMFPlans() {
			String format = "%1$-20s%2$-20s%3$-20s\n";
			String string = "ID";
			String string2 = "Title";
			String string3 = "NAV(INR)";
			System.out.println("----------------------------------------------------");
			System.out.format(format, string, string2, string3);
			System.out.println("----------------------------------------------------");
			try {
				for (Entry<Integer, BankMutualFund> entry : service.viewMFPlans().entrySet()) {

					System.out.format(format, entry.getValue().getMfPlanId(), entry.getValue().getTitle(),
							entry.getValue().getNav());
				}
				log.info("User views Mutual fund offerd by bank");
			} catch (IBSException e) {
				log.error(e);
				System.out.println(e.getMessage());
			}

		}

		// Customer buys Silver
		public void buySilver(String userId) {
			boolean success = true;
			System.out.println("Enter number of silver units to buy(in grams):");
			String goldUnits = sc.next();
			double GoldUnits = 0;

			try {
				while (success) {
					if (goldUnits.matches("[+]?[0-9]*\\.?[0-9]+")) {
						GoldUnits = Double.parseDouble(goldUnits);
						if (GoldUnits > 0) {

							success = false;
						} else {
							System.out.println("Please  Re-enter the value");
							goldUnits = sc.next();
						}
					} else {

						System.out.println("Please  Re-enter the value");
						goldUnits = sc.next();

					}
				}

				service.buySilver(GoldUnits, userId);
				System.out.println("transaction completed");
				log.info("user buys silver");
			} catch (IBSException e) {
				log.error(e);
				System.out.println(e.getMessage());
			}
		}

		// Customer invests in a Mutual Fund
		public void investMFPlan(String userId) {

			String format = "%1$-20s%2$-20s%3$-20s\n";
			String string = "ID";
			String string2 = "Title";
			String string3 = "NAV(INR)";
			System.out.println("----------------------------------------------------");
			System.out.format(format, string, string2, string3);
			System.out.println("----------------------------------------------------");
			try {
				for (Entry<Integer, BankMutualFund> entry : service.viewMFPlans().entrySet()) {

					System.out.format(format, entry.getValue().getMfPlanId(), entry.getValue().getTitle(),
							entry.getValue().getNav());
				}

			} catch (IBSException e) {
				log.error(e);
				System.out.println(e.getMessage());
			}

			try {
				int mfId = 0;
				boolean check = true;
				boolean check1 = true;
				double mfAmount = 0;
				System.out.println("Enter the mutual fund Id:");
				String temp = sc.next();
				while (check) {

					if (temp.matches("[1-9][0-9]{2,10}")) {

						mfId = Integer.parseInt(temp);
						if (service.viewMFPlans().containsKey(mfId)) {

							check = false;
						} else {
							System.out.println("Please enter valid MfId");
							temp = sc.next();

						}

					}

					else {
						System.out.println("Please Re-enter the value");
						temp = sc.next();

					}

				}

				System.out.println("Enter the amount to invest");
				temp = sc.next();
				while (check1) {
					if (temp.matches("[+]?[0-9]*\\.?[0-9]+")) {
						mfAmount = Double.parseDouble(temp);
						if (mfAmount > 0) {
							check1 = false;
						} else {
							System.out.println("Please Re-enter the value");
							temp = sc.nextLine();

						}

					} else {
						System.out.println("Please Re-enter the value");
						temp = sc.next();

					}

				}

				service.investDirMF(mfAmount, userId, mfId);
				System.out.println("transaction completed");
				log.info("User invests in mutual fund");
			} catch (IBSException e) {
				log.error(e);
				System.out.println(e.getMessage());

			}
		}

		// Customer withdraws from a Mutual Fund
		public void withdrawMFPlan(String userId) {
			List<MutualFund> InvestmentList;
			MutualFund mutualFund = null;
			boolean check = true;
			try {
				Map<Integer, Integer> SerialNumber = new HashMap();
				int k = 1;
				InvestmentList = new ArrayList<>(service.viewInvestments(userId).getFunds());
				List<MutualFund> openinvestmentList = new ArrayList<>();
				for (int i = 0; i < InvestmentList.size(); i++) {
					if (InvestmentList.get(i).getClosingDate() == null) {

						openinvestmentList.add(InvestmentList.get(i));
					}

				}
				if (openinvestmentList.size() > 0) {

					DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/YYYY");
					String format = "%1$-20s%2$-20s%3$-20s%4$-20s%5$-20s%6$-20s\n";

					String string = "MfId";
					String string1 = "Title";
					String string2 = "NAV";
					String string3 = "Mf Units";
					String string4 = "Opening Date";
					String string5 = "Sr.No";

					System.out.println(
							"-----------------------------------------------------------------------------------------------------------------");
					System.out.format(format, string5, string, string1, string2, string3, string4);
					System.out.println(
							"-----------------------------------------------------------------------------------------------------------------");
					for (int i = 0; i < InvestmentList.size(); i++) {
						if (InvestmentList.get(i).getClosingDate() == null) {
							SerialNumber.put(k, i);
							MutualFund temp = InvestmentList.get(i);

							System.out.format(format, k, temp.getFolioNumber(), temp.getBankMutualFund().getTitle(),
									temp.getBankMutualFund().getNav(), (Math.round(temp.getMfUnits() * 100)) / 100,
									formatter.format(temp.getOpeningDate()));

							k++;
						}

					}
					System.out.println("Enter the plan number you want to choose");
					String temp = sc.next();
					while (check) {
						if (temp.matches("[0-9]{1,2}")) {
							int index = Integer.parseInt(temp);
							if (index <= InvestmentList.size() && index >= 0) {
								if (SerialNumber.get(index) != null) {
									mutualFund = InvestmentList.get(SerialNumber.get(index));

									if (mutualFund != null) {
										service.withdrawDirMF(userId, mutualFund);
										check = false;
									} else {
										System.out.println("Please Re-enter the index of the plan");
										temp = sc.next();

									}
								} else {
									System.out.println("Please Re-enter the index of the plan");
									temp = sc.next();

								}
							} else {
								System.out.println("Please Re-enter the index of the plan");
								temp = sc.next();
							}
						} else {
							System.out.println("Please enter valid index of the plan");
							temp = sc.next();

						}
					}

					System.out.println("transaction completed");
				} else {
					System.out.println("Sorry!! you have to buy new plans");
				}
				log.info("user withdraws from mutual fund");
			} catch (IBSException exp) {
				log.error(exp);
				System.out.println(exp.getMessage());
			}

		}

		
		
		
		
		

		public void viewMyTransactions(String userId) {
			try {

				DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/YYYY hh:mm");
				String format = "%1$-10s%2$-20s%3$-35s%4$-20s%5$-20s%6$-20s\n";

				String string = "TransId";
				String string1 = "TransDate";
				String string2 = "Description";
				String string3 = "Amount(INR)";
				String string4 = "Type";
				String string5 = "Units";
				String string6 = "PricePerUnit/NAV(INR)";

				System.out.println(
						"-------------------------------------------------------------------------------------------------------------------");
				System.out.format(format, string, string1, string2, string3, string4, string5, string6);
				System.out.println(
						"-------------------------------------------------------------------------------------------------------------------");

				List<InvestmentTransaction> tsBeans = service.getTransactions(userId);
				for (InvestmentTransaction t : tsBeans) {

					System.out.format(format, t.getTransactionId(), formatter.format(t.getTransactionDate()),
							t.getTransactionDescription(), t.getTransactionAmount().setScale(2, BigDecimal.ROUND_DOWN),
							t.getTransactionType(), Math.round(t.getUnits() * 100.00) / 100.00, t.getPricePerUnit());
				}

				log.info("User views transaction");
			} catch (IBSException e) {
				log.error(e);
				System.out.println(e.getMessage());
			}

		}

		public void linkAccount(String userId) {
			try {
				int i = 1;
				boolean check = true;
				for (AccountBean a : service.getAccountList(userId)) {
					System.out.println(
							i + "\t\t" + a.getAccNo() + "\t\t" + a.getBalance().setScale(2, BigDecimal.ROUND_DOWN));
					i++;
				}
				System.out.println("Choose the account number you want to link");

				String temp = sc.next();
				int a = 0;
				while (check) {
					if (temp.matches("[0-9]{1,2}")) {
						a = Integer.parseInt(temp);
						if (a <= service.getAccountList(userId).size() && a > 0) {
							check = false;
						} else {
							System.out.println("Please Re-enter the choice");
							temp = sc.next();

						}

					} else {

						System.out.println("Please Re-enter the choice");
						temp = sc.next();

					}
				}

				BigInteger accountNumber = service.getAccountList(userId).get(a - 1).getAccNo();
				System.out.println("You have chosen the account---" + accountNumber.toString());
				service.linkMyAccount(accountNumber, userId);
			} catch (IBSException e) {
				System.out.println(e.getMessage());

			}

		}	
}
