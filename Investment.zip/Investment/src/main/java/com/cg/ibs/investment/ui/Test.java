package com.cg.ibs.investment.ui;

import java.math.BigInteger;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.Period;
import java.time.temporal.ChronoUnit;
import java.util.HashSet;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.stereotype.Component;

import com.cg.ibs.investment.bean.BankAdmins;
import com.cg.ibs.investment.bean.InvestmentBean;
import com.cg.ibs.investment.dao.BankAdminsDao;
import com.cg.ibs.investment.dao.BankAdminsDaoImpl;
import com.cg.ibs.investment.dao.CustomerDaoImpl;
import com.cg.ibs.investment.dao.InvestmentDaoImpl;
import com.cg.ibs.investment.service.CustomerService;
import com.cg.ibs.investment.service.CustomerServiceImpl;
@Component
public class Test {

	public static void main(String[] args) {
		/*//.info("entered  autodeduction in autopaymentservimpl");
		 EntityTransaction transaction = JPAUtil.getTransaction();
		 LocalDate today = LocalDate.now();
		 boolean validAutoDeduct = false;
		// LOGGER.debug(autoPaymentDao.getCurrentBalance(accountNumber));
		 if (Pattern.matches("^(0[1-9]|[12][0-9]|3[01])/(0[1-9]|1[012])/((?:[0-9]{2})?[0-9]{2})$", autoPayment.getDateOfStart())) {
		  DateTimeFormatter dtFormatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");
		  LocalDate startOfAutoPayment = LocalDate.parse(autoPayment.getDateOfStart(), dtFormatter);
		  if (!transaction.isActive()) {
		   transaction.begin();
		  }
		  if (!startOfAutoPayment.isBefore(today)) {
		   autoPaymentDao.copyDetails(uci, autoPayment);
		   if (today.equals(startOfAutoPayment)
		     && (0 <= autoPaymentDao.getCurrentBalance(accountNumber).compareTo(autoPayment.getAmount()))) {
		    BigDecimal balance = autoPaymentDao.getCurrentBalance(accountNumber)
		      .subtract(autoPayment.getAmount());
		    autoPaymentDao.setCurrentBalance(balance, accountNumber);
		    startOfAutoPayment.plusMonths(1);
		    //LOGGER.debug(autoPaymentDao.getCurrentBalance(accountNumber));
		   
		   }
		   validAutoDeduct = true;
		  }
		  transaction.commit();
		 }
		 
		 return validAutoDeduct;
		}*/
	
		/* Set set = new HashSet();
		 
	        //Adding values to the HashSet
	        set.add("test1");
	        set.add("test2");
	        set.add("test3");
	 
	        System.out.println("Retrieving values from HashSet using Iterator");
	      for (Object object : set) {
	    	  String i=(String) object;
	    	  System.out.println(i);
	    	  
		}*/
	      //LocalDate dt=LocalDate.of(2005, 5, 15);
		
		//System.out.println(Period.between(dt,LocalDate.now()));
		//int i=Period.between(dt,LocalDate.now()).;
	//System.out.println(i);
		
		BankAdminsDao daoObject = new BankAdminsDaoImpl();
		BankAdmins cs = daoObject.getBankById("id1");
		System.out.println(cs.getPassword());
	}

}

