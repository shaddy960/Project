package com.cg.ibs.investment.ui;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.math.MathContext;
import java.time.LocalDate;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.EntityManager;

import com.cg.ibs.investment.bean.AccountBean;
import com.cg.ibs.investment.bean.AccountHoldingBean;
import com.cg.ibs.investment.bean.AccountHoldingType;
import com.cg.ibs.investment.bean.AccountStatus;
import com.cg.ibs.investment.bean.AccountType;
import com.cg.ibs.investment.bean.BankMutualFund;
import com.cg.ibs.investment.bean.CustomerBean;
import com.cg.ibs.investment.bean.Gender;
import com.cg.ibs.investment.bean.GoldPrice;
import com.cg.ibs.investment.bean.InvestmentBean;
import com.cg.ibs.investment.bean.MutualFund;
import com.cg.ibs.investment.bean.SilverPrice;
import com.cg.ibs.investment.dao.AccountDao;
import com.cg.ibs.investment.dao.AccountDaoImpl;
import com.cg.ibs.investment.dao.CustomerDao;
import com.cg.ibs.investment.dao.CustomerDaoImpl;
import com.cg.ibs.investment.service.AdditionService;
import com.cg.ibs.investment.service.CSIMPL;
import com.cg.ibs.investment.service.FetchService;
import com.cg.ibs.investment.util.JPAUtil;

public class Test {

	public static void main(String[] args) {
		
		 BigDecimal bg=new BigDecimal("5001.000000000000909494701772928237915039062");
		 System.out.println(bg.setScale(2, BigDecimal.ROUND_FLOOR));
	
		
		
		
		
	}

}
