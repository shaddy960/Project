package com.cg.ibs.investment.ui;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.math.MathContext;
import java.time.LocalDate;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.EntityManager;

import com.cg.ibs.investment.bean.AccountBean;
import com.cg.ibs.investment.bean.AccountHoldingBean;
import com.cg.ibs.investment.bean.AccountHoldingType;
import com.cg.ibs.investment.bean.AccountStatus;
import com.cg.ibs.investment.bean.AccountType;
import com.cg.ibs.investment.bean.BankMutualFund;
import com.cg.ibs.investment.bean.CustomerBean;
import com.cg.ibs.investment.bean.Gender;
import com.cg.ibs.investment.bean.GoldPrice;
import com.cg.ibs.investment.bean.InvestmentBean;
import com.cg.ibs.investment.bean.MutualFund;
import com.cg.ibs.investment.bean.SilverPrice;
import com.cg.ibs.investment.dao.AccountDao;
import com.cg.ibs.investment.dao.AccountDaoImpl;
import com.cg.ibs.investment.dao.CustomerDao;
import com.cg.ibs.investment.dao.CustomerDaoImpl;
import com.cg.ibs.investment.service.AdditionService;
import com.cg.ibs.investment.service.CSIMPL;
import com.cg.ibs.investment.service.FetchService;
import com.cg.ibs.investment.util.JPAUtil;

public class Test {

	public static void main(String[] args) {
		AdditionService as=new AdditionService();
		BankMutualFund bk=new BankMutualFund();
		bk.setMfPlanId(10002);
		bk.setNav(new Double(300));
		bk.setTitle("IBS_Savings");
		bk.setLaunchDate(LocalDate.of(2014, 1, 20));
		bk.setMinAmtDir(new Double(5000));
		bk.setMinAmtSip(new Double(500));
		bk.setSipStatus(true);
		//bk.setStatus(true);
		as.addBankMutualFund(bk);
	
		
		
		
		
	}

}
