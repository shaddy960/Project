package com.cg.ibs.investment.bean;

public enum SIPStatus {
	ON,OFF
}
