package com.cg.ibs.investment.bean;

public enum Frequency {
MONTHLY, QUATERLY, HALFYEARLY, ANNUALLY
}
