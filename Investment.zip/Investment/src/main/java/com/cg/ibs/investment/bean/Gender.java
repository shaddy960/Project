package com.cg.ibs.investment.bean;

public enum Gender {
MALE, FEMALE
}
