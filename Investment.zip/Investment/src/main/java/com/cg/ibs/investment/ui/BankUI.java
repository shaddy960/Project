package com.cg.ibs.investment.ui;

import java.util.Scanner;
import java.util.Map.Entry;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.stereotype.Component;

import com.cg.ibs.investment.bean.BankMutualFund;
import com.cg.ibs.investment.exception.IBSException;
import com.cg.ibs.investment.service.BankService;
import com.cg.ibs.investment.service.BankServiceImpl;
import com.cg.ibs.investment.service.CustomerService;
import com.cg.ibs.investment.service.CustomerServiceImpl;
@Component
public class BankUI {
	static Scanner sc=new Scanner(System.in);
	//static int status = 3;
	static Logger log = Logger.getLogger(InvestmentUI.class.getName());
//	ApplicationContext context=new ClassPathXmlApplicationContext("investment.xml");

	// Declaring objects of Client Service and Bank Service
	/*CustomerService service = new CustomerServiceImpl();
	BankService bankservice = new BankServiceImpl();*/
	@Autowired
	CustomerService service;
	@Autowired
	BankService bankservice;

	public void updateNav() {

		boolean check = true;
		try {

			String format = "%1$-20s%2$-20s%3$-20s\n";
			String string = "ID";
			String string2 = "Title";
			String string3 = "NAV(INR)";
			System.out.println("----------------------------------------------------");
			System.out.format(format, string, string2, string3);
			System.out.println("----------------------------------------------------");

			for (Entry<Integer, BankMutualFund> entry : service.viewMFPlans().entrySet()) {

				System.out.format(format, entry.getValue().getMfPlanId(), entry.getValue().getTitle(),
						entry.getValue().getNav());
			}

			System.out.println("Enter the plan Id you want to choose");
			int mfPlanId = 0;
			String temp = sc.next();
			while (check) {
				if (temp.matches("[0-9]{1,10}")) {
					mfPlanId = Integer.parseInt(temp);

					if (service.viewMFPlans().containsKey(mfPlanId)) {

						check = false;
					} else {
						System.out.println("Please enter correct planId");
						temp = sc.next();
					}
				} else {
					System.out.println("Please enter valid planId");
					temp = sc.next();

				}
			}
			System.out.println("Enter nav value");
			String navTemp = sc.next();
			double nav = 0;
			boolean check1 = true;
			while (check1) {
				if (navTemp.matches("[+]?[0-9]*\\.?[0-9]+")) {
					nav = Double.parseDouble(navTemp);
					if (nav > 0) {
						check1 = false;
					} else {
						System.out.println("Please enter the valid NAV");
						navTemp = sc.next();
					}
				} else {
					System.out.println("Please Re-enter the value");
					navTemp = sc.next();
				}

			}
			bankservice.updateNav(mfPlanId, nav);

			System.out.println("transaction completed");
			log.info("user withdraws from mutual fund");
		} catch (IBSException exp) {
			log.error(exp);
			System.out.println(exp.getMessage());
		}

	}

	// Bank representative updates gold price
	public void updateGoldPrice() {
		boolean success = true;
		System.out.println("Enter the updated gold price");
		String goldPrice = sc.next();
		double GoldPrice = 0;
		try {
			while (success) {
				if (goldPrice.matches("[+]?[0-9]*\\.?[0-9]+")) {
					GoldPrice = Double.parseDouble(goldPrice);
					if (GoldPrice > 0) {

						success = false;
					} else {
						System.out.println("Please  Re-enter the value");
						goldPrice = sc.next();
					}
				} else {

					System.out.println("Please  Re-enter the value");
					goldPrice = sc.next();

				}
			}

			if (bankservice.updateGoldPrice(GoldPrice)) {
				System.out.println("Gold Price updated successfully");
			} else {
				System.out.println("Already updated");
			}
			log.info("Bank updates Gold Price");
		} catch (IBSException e) {
			log.error(e);
			System.out.println(e.getMessage());
		}
	}

	// Bank representative updates Silver price
	public void updateSiverPrice() {
		boolean success = true;
		System.out.println("Enter the updated silver price");
		String silverPrice = sc.next();
		double SilverPrice = 0;
		try {
			while (success) {
				if (silverPrice.matches("[+]?[0-9]*\\.?[0-9]+")) {
					SilverPrice = Double.parseDouble(silverPrice);
					if (SilverPrice > 0) {

						success = false;
					} else {
						System.out.println("Please  Re-enter the value");
						silverPrice = sc.next();
					}
				} else {

					System.out.println("Please  Re-enter the value");
					silverPrice = sc.next();

				}
			}

			if (bankservice.updateSilverPrice(SilverPrice)) {
				System.out.println("Silver Price updated successfully");
			} else {
				System.out.println("Already updated");
			}

			log.info("Bank updates silver price");
		} catch (IBSException e) {
			log.error(e);
			System.out.println(e.getMessage());
		}
	}

	// Bank representative adds Mutual Fund plans
	public void addMFPlans() {
		boolean check = true;
		System.out.println("Enter mutualfundId");
		String temp = sc.next();
		int mfId = 0;
		while (check) {

			if (temp.matches("[1-9][0-9]{2,10}")) {

				mfId = Integer.parseInt(temp);
				try {
					if (service.viewMFPlans().containsKey(mfId) == false) {

						check = false;
					} else {
						System.out.println("MF Id already exists.");
						temp = sc.nextLine();

					}

				} catch (IBSException e) {
					log.error(e);
					System.out.println(e.getMessage());
				}

			}

			else {
				System.out.println("Please Re-enter the value");
				temp = sc.next();

			}

		}

		boolean check1 = true;
		System.out.println("Enter mutualfundtitle");
		String title = sc.next();

		System.out.println("Enter nav value");
		String navTemp = sc.next();
		double nav = 0;
		while (check1) {
			if (navTemp.matches("[+]?[0-9]*\\.?[0-9]+")) {
				nav = Double.parseDouble(navTemp);
				if (nav > 0) {
					check1 = false;
				} else {
					System.out.println("Please enter the valid NAV");
					navTemp = sc.next();
				}
			} else {
				System.out.println("Please Re-enter the value");
				navTemp = sc.next();
			}

		}

		try {
			BankMutualFund MF = new BankMutualFund();
			MF.setTitle(title);
			MF.setMfPlanId(mfId);
			MF.setNav(nav);

			bankservice.addMF(MF);
			System.out.println("Mutual Fund plans updated successfully");
			log.info("Bank adds Mutual Fund");
		} catch (IBSException e) {
			log.error(e);
			System.out.println(e.getMessage());
		}

	}
}
