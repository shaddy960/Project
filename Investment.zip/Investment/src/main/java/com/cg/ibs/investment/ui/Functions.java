package com.cg.ibs.investment.ui;

public enum Functions {
VIEW,UPDATE,GO_BACK

}
