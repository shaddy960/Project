package com.cg.ibs.investment.exception;

public class IBSException extends Exception {
	public IBSException(String message) {
		super(message);
	}

}
