package com.cg.ibs.investment.controller;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.cg.ibs.investment.bean.BankMutualFund;
import com.cg.ibs.investment.exception.IBSException;
import com.cg.ibs.investment.service.BankService;
import com.cg.ibs.investment.service.CustomerService;

@Controller
@Scope("session")
public class BankController {
	@Autowired
	private CustomerService service;
	@Autowired
	private BankService bankService;
	
	@RequestMapping("/bank")
	public ModelAndView showBankLogin(){
		ModelAndView mv = new ModelAndView();
		mv.setViewName("bankLogin");
		return mv;
	}
	@RequestMapping(method = RequestMethod.POST,value = "/bankLogin")
	public ModelAndView bankLogin(@RequestParam("userId") String userId, @RequestParam("password") String password ){
		Boolean result;
		ModelAndView mv = new ModelAndView();
		try {
			result = bankService.validateBank(userId, password);
			if(result==true){
				mv.setViewName("bankMenu");
			}else {
				mv.setViewName("showMessage");
			}
		} catch (IBSException e) {
			mv.addObject("message",e.getMessage());
			mv.setViewName("errorPage");
		}
		
		return mv;
	}
	@RequestMapping("/bankGold")
	public ModelAndView manageGold() {
		ModelAndView mv=new ModelAndView();
		mv.setViewName("bankGoldMenu");
		return mv;
	}
	
	@RequestMapping("/viewGPrice")
	public ModelAndView viewGoldPrice() {
		ModelAndView mv = new  ModelAndView();
		try {
			mv.addObject("price",service.viewGoldPrice());
			mv.setViewName("bankGoldMenu");
		} catch (IBSException e) {
			mv.addObject("message",e.getMessage());
			mv.setViewName("errorPage");
		}
		return mv;
	}
	
	@RequestMapping("/updateGPrice")
	public ModelAndView updateGoldPriceView() {
		ModelAndView mv = new ModelAndView();
		mv.setViewName("updateGoldPrice");
		return mv;
	}
	
	@RequestMapping("/updateGoldPricemethod")
	public ModelAndView updateGoldPrice(@RequestParam("goldPrice") Double goldPrice) {
		ModelAndView mv = new ModelAndView();
		Boolean result;
		 
		try {
			result =bankService.updateGoldPrice(goldPrice);
			if(result==true) {
				mv.addObject("message","Gold Price updated successfully");
				mv.setViewName("bankMenu");
			}else {
				mv.addObject("message","Gold Price is already updated today");
				mv.setViewName("bankMenu");
			}
			
		} catch (IBSException e) {
			mv.addObject("message",e.getMessage());
			mv.setViewName("errorPage");
			}
		return mv;
	}
	
	@RequestMapping("/bankSilver")
	public ModelAndView manageSilver() {
		ModelAndView mv = new ModelAndView();
		mv.setViewName("bankSilverMenu");
		return mv;
	}
	
	@RequestMapping("/viewSPrice")
	public ModelAndView viewSilverPriceView() {
		ModelAndView mv = new ModelAndView();
		try {
			mv.addObject("price",service.viewSilverPrice());
			mv.setViewName("bankSilverMenu");
		} catch (IBSException e) {
			mv.addObject("message",e.getMessage());
			mv.setViewName("errorPage");
		}
		return mv;
	}
	
	@RequestMapping("/updateSPrice")
	public ModelAndView updateSilverPriceView() {
		ModelAndView mv = new ModelAndView();
		mv.setViewName("updateSilverPrice");
		return mv;
	}
	
	@RequestMapping("/updateSilverPriceMethod")
	public ModelAndView updateSilverprice(@RequestParam("silverPrice") Double silverPrice) {
		ModelAndView mv = new ModelAndView();
		Boolean result;
		try {
			result = bankService.updateSilverPrice(silverPrice);
			if (result==true) {
				mv.addObject("message","Silver Price updated successfully");
				mv.setViewName("bankMenu");
			} else {
				mv.addObject("message","Silver Price is already updated today");
				mv.setViewName("bankMenu");
			}
		} catch (IBSException e) {
			mv.addObject("message",e.getMessage());
			mv.setViewName("errorPage");
		}
		return mv;
	}
	
	@RequestMapping("/bankMfMenu")
	public ModelAndView manageMutualFunds() {
		ModelAndView mv = new ModelAndView();
		mv.setViewName("bankMfMenu");
		return mv;
	}
	
	@RequestMapping("/bankViewMfs")
	public ModelAndView viewMfs() {
		ModelAndView mv = new ModelAndView();
		try {
		HashMap<Integer, BankMutualFund> map = service.viewMFPlans();
		List<BankMutualFund> mfPlans = new ArrayList<BankMutualFund>(map.values());
		mv.addObject("bankMutualFund",mfPlans);
		mv.setViewName("bankViewMfs");
		} catch (IBSException e) {
			mv.addObject("message",e.getMessage());
			mv.setViewName("errorPage");
		}
		
		return mv;
	}
	
	@RequestMapping("/addMutualFund")
	public ModelAndView addMutualFundView(){
		ModelAndView mv = new ModelAndView();
		mv.setViewName("addMutualFund");
		return mv;
	}
	
	@RequestMapping("/addMutualFundMethod")
	public ModelAndView addMutualFundMethod(@ModelAttribute BankMutualFund bmf) {
		ModelAndView mv = new ModelAndView();
		try {
			bankService.addMF(bmf);
			mv.addObject("message","You successfully added a Mutual Fund");
			mv.setViewName("bankMfMenu");
		} catch (IBSException e) {
			mv.addObject("message",e.getMessage());
			mv.setViewName("errorPage");
		}
		return mv;
	}
	
	
	@RequestMapping("/bankUpdateMfs")
	public ModelAndView bankUpdateMfMenu() {
		ModelAndView mv = new ModelAndView();
		mv.setViewName("bankUpdateMfs");
		return mv;
	}
	
	@RequestMapping("/updateNav")
	public ModelAndView updateNavView() {
		ModelAndView mv = new ModelAndView();
		mv.setViewName("updateNav");
		return mv;
	}
	
	
	  @RequestMapping("/updateNavMethod") 
	  public ModelAndView updateNavMethod(@RequestParam("mfPlanId")Integer mfPlanId,@RequestParam("nav") Double nav) {
	  ModelAndView mv = new ModelAndView();
		  try {
			bankService.updateNav(mfPlanId, nav);
			mv.addObject("message","You successfully updated Nav of the Mutual Fund plan");
			mv.setViewName("bankMfMenu");
		} catch (IBSException e) {
			mv.addObject("message",e.getMessage());
			mv.setViewName("updateNav");
		}
	  return mv;
	  }
	  
	  @RequestMapping("/updateMdaMf")
	  public ModelAndView updateMdaMfView() {
		  ModelAndView mv = new ModelAndView();
		  mv.setViewName("updateMdaMf");
		  return mv;
	  }
	  
	  @RequestMapping("/updateMdaMethod")
	  public ModelAndView updateMdaMfMethod(@RequestParam("mfPlanId")Integer mfPlanId,@RequestParam("minAmtDir") Double minAmtDir) {
		  ModelAndView mv = new ModelAndView();
		  try {
			bankService.updateMinDir(mfPlanId, minAmtDir);
			mv.addObject("message", "You successfully updated minimum amount for Direct Investment for the selected Mutual Fund");
			mv.setViewName("bankMfMenu");
		  } catch (IBSException e) {
			  mv.addObject("message",e.getMessage());
				mv.setViewName("updateMdaMf");
		}
		  return mv;
	  }
	  
	  @RequestMapping("/updateMsaMf")
	  public ModelAndView updateMsaMfView() {
		  ModelAndView mv = new ModelAndView();
		  mv.setViewName("updateMsaMf");
		  return mv;
	  }
	  
	  @RequestMapping("/updateMsaMethod")
	  public ModelAndView updateMsaMfMethod(@RequestParam("mfPlanId")Integer mfPlanId,@RequestParam("minAmtSip") Double minAmtSip) {
		  ModelAndView mv = new ModelAndView();
		  try {
			bankService.updateMinSip(mfPlanId, minAmtSip);
			mv.addObject("message", "You successfully updated minimum amount for SIP Investment of the selected Mutual Fund");
			mv.setViewName("bankMfMenu");
		  } catch (IBSException e) {
			  mv.addObject("message",e.getMessage());
				mv.setViewName("updateMsaMf");
		}
		  return mv;
	  }
	 
	  @RequestMapping("/updateSipStatus")
	  public ModelAndView updateSipStatusView() {
		  ModelAndView mv = new ModelAndView();
		  mv.setViewName("updateSipStatus");
		  return mv;
	  }
	  
	  @RequestMapping("/updateSipStatusMethod")
	  public ModelAndView updateSipStatusMethod(@RequestParam("mfPlanId")Integer mfPlanId, @RequestParam("sipStatus") Boolean sipStatus) {
		  ModelAndView mv = new ModelAndView();
		  try {
			bankService.updateSipStatus(mfPlanId, sipStatus);
			mv.addObject("message","You successfully updated SIP status of the selected Mutual Fund ");
			mv.setViewName("bankMfMenu");
		  } catch (IBSException e) {
			  mv.addObject("message",e.getMessage());
				mv.setViewName("updateSipStatus");
		}
		  return mv;
	  }
	  
	  @RequestMapping("/updateDirStatus")
	  public ModelAndView updateDirStatusView() {
		  ModelAndView mv = new ModelAndView();
		  mv.setViewName("updateDirStatus");
		  return mv;
	  }
	  
	  @RequestMapping("/updateDirStatusMethod")
	  public ModelAndView updateDirStatusMethod(@RequestParam("mfPlanId")Integer mfPlanId, @RequestParam("dirStatus") Boolean dirStatus ) {
		  ModelAndView mv = new ModelAndView();
		  try {
			bankService.updateDirStatus(mfPlanId, dirStatus);
			mv.addObject("message","You successfully updated Direct status of the selected Mutual Fund ");
			mv.setViewName("bankMfMenu");
		  } catch (IBSException e) {
			  mv.addObject("message",e.getMessage());
				mv.setViewName("updateDirStatus");
		}
		  return mv;
	  }
	
	  @RequestMapping("/bankRemoveMfs")
	  public ModelAndView removeMfsView() {
		  ModelAndView mv = new ModelAndView();
		  mv.setViewName("bankRemoveMfs");
		  return mv;
	  }
	  
	  @RequestMapping("/removeMfs")
	  public ModelAndView removeMfsMethod(@RequestParam("mfPlanId")Integer mfPlanId) {
		  ModelAndView mv = new ModelAndView();
		 try { bankService.removeMF(mfPlanId);
		  mv.addObject("message","You successfully removed the Mutual Fund plan");
		  mv.setViewName("bankMfMenu");
		 }catch(IBSException e){
			 mv.addObject("message",e.getMessage());
				mv.setViewName("bankRemoveMfs");
		 }
		 return mv;
	  }
	  @RequestMapping("/bankDash")
		public ModelAndView viewCustDash() {
			return new ModelAndView("bankMenu");
		}
}
