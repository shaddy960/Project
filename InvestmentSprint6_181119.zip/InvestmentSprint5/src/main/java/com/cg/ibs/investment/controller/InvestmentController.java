package com.cg.ibs.investment.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class InvestmentController {
	
	@RequestMapping({"/","/home"})
	public String showHome(){
		return "homePage";
	}

	@RequestMapping("/menu")
	public String showMenu(){
		return "menuPage";
	}
	
	@RequestMapping({"/custLogOut","/bankLogOut"})
	public ModelAndView logOut() {
		ModelAndView mv = new ModelAndView();
		mv.setViewName("homePage");
		mv.addObject("message","You are Successfully logged out !!");
		return mv;
	}
}
