package com.cg.ibs.investment.dao;

import java.math.BigInteger;
import java.util.List;

import com.cg.ibs.investment.bean.Account;

public interface AccountDao {
	Account addAccount(Account account);

	Account updateAccount(Account account);

	Account getAccountByAccNo(BigInteger accNo);

	List<Account> getAllAccounts();

	boolean removeAccount(BigInteger accNo);

	
}
