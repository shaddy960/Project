package com.cg.ibs.investment.model;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.time.LocalDateTime;

import com.cg.ibs.investment.bean.TransactionMode;
import com.cg.ibs.investment.bean.TransactionType;

public class TransactionView {
	private Integer transactionId;
private TransactionType transactionType;
private  LocalDateTime transactionDate;
private BigDecimal transactionAmount;
private  TransactionMode transactionMode;
private String transactionDescription;
private  BigDecimal transactionBalance;
private BigInteger accountNumber;
private  Double pricePerUnits;
private  Double units;
public Integer getTransactionId() {
	return transactionId;
}
public void setTransactionId(Integer transactionId) {
	this.transactionId = transactionId;
}
public TransactionType getTransactionType() {
	return transactionType;
}
public void setTransactionType(TransactionType transactionType) {
	this.transactionType = transactionType;
}
public LocalDateTime getTransactionDate() {
	return transactionDate;
}
public void setTransactionDate(LocalDateTime transactionDate) {
	this.transactionDate = transactionDate;
}
public BigDecimal getTransactionAmount() {
	return transactionAmount;
}
public void setTransactionAmount(BigDecimal transactionAmount) {
	this.transactionAmount = transactionAmount;
}
public TransactionMode getTransactionMode() {
	return transactionMode;
}
public void setTransactionMode(TransactionMode transactionMode) {
	this.transactionMode = transactionMode;
}
public String getTransactionDescription() {
	return transactionDescription;
}
public void setTransactionDescription(String transactionDescription) {
	this.transactionDescription = transactionDescription;
}
public BigDecimal getTransactionBalance() {
	return transactionBalance;
}
public void setTransactionBalance(BigDecimal transactionBalance) {
	this.transactionBalance = transactionBalance;
}
public BigInteger getAccountNumber() {
	return accountNumber;
}
public void setAccountNumber(BigInteger accountNumber) {
	this.accountNumber = accountNumber;
}
public Double getPricePerUnits() {
	return pricePerUnits;
}
public void setPricePerUnits(Double pricePerUnits) {
	this.pricePerUnits = pricePerUnits;
}
public Double getUnits() {
	return units;
}
public void setUnits(Double units) {
	this.units = units;
}


}
