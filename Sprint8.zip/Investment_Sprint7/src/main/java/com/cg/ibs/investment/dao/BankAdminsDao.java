package com.cg.ibs.investment.dao;


import com.cg.ibs.investment.bean.BankAdmins;
import com.cg.ibs.investment.bean.Banker;

public interface BankAdminsDao {
	BankAdmins addBankAdmins(BankAdmins bank);

	BankAdmins getBankById(String id);
	
	

}
