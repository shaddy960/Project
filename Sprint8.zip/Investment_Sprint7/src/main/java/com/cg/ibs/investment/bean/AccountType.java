package com.cg.ibs.investment.bean;

public enum AccountType {
	SAVINGS, FIXED_DEPOSIT, RECURRING_DEPOSIT, JOINT_SAVINGS;
}
