package com.cg.ibs.investment.model;

import java.time.LocalDate;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;

import com.cg.ibs.investment.bean.BankMutualFund;
import com.cg.ibs.investment.bean.Frequency;
import com.cg.ibs.investment.bean.InvestmentBean;
import com.cg.ibs.investment.bean.MFType;

public class MutualView {
	
	private Integer folioNumber;
	
	private String planName;
			
	private Double mfUnits;
	
	private Double mfAmount;
	
	private LocalDate openingDate;

	private LocalDate closingDate;
	
	private Integer duration;
	
	private Integer installments;
	
	private Frequency frequency;
	
	private Boolean status;
	
	private MFType type;
	
	private LocalDate nextInstallDate;
	
	private LocalDate buyDate;
	
	

	public Integer getFolioNumber() {
		return folioNumber;
	}

	public void setFolioNumber(Integer folioNumber) {
		this.folioNumber = folioNumber;
	}

	public String getPlanName() {
		return planName;
	}

	public void setPlanName(String planName) {
		this.planName = planName;
	}

	public Double getMfUnits() {
		return mfUnits;
	}

	public void setMfUnits(Double mfUnits) {
		this.mfUnits = mfUnits;
	}

	public Double getMfAmount() {
		return mfAmount;
	}

	public void setMfAmount(Double mfAmount) {
		this.mfAmount = mfAmount;
	}

	public LocalDate getOpeningDate() {
		return openingDate;
	}

	public void setOpeningDate(LocalDate openingDate) {
		this.openingDate = openingDate;
	}

	public LocalDate getClosingDate() {
		return closingDate;
	}

	public void setClosingDate(LocalDate closingDate) {
		this.closingDate = closingDate;
	}

	public Integer getDuration() {
		return duration;
	}

	public void setDuration(Integer duration) {
		this.duration = duration;
	}

	public Integer getInstallments() {
		return installments;
	}

	public void setInstallments(Integer installments) {
		this.installments = installments;
	}

	public Frequency getFrequency() {
		return frequency;
	}

	public void setFrequency(Frequency frequency) {
		this.frequency = frequency;
	}

	public Boolean getStatus() {
		return status;
	}

	public void setStatus(Boolean status) {
		this.status = status;
	}

	public MFType getType() {
		return type;
	}

	public void setType(MFType type) {
		this.type = type;
	}

	public LocalDate getNextInstallDate() {
		return nextInstallDate;
	}

	public void setNextInstallDate(LocalDate nextInstallDate) {
		this.nextInstallDate = nextInstallDate;
	}

	public LocalDate getBuyDate() {
		return buyDate;
	}

	public void setBuyDate(LocalDate buyDate) {
		this.buyDate = buyDate;
	}

	
	
}
