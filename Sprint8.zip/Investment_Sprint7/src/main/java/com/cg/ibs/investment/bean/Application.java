package com.cg.ibs.investment.bean;

import java.time.LocalDate;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@NamedQueries({ @NamedQuery(name = "getAllApplications", query = "select a.applicationId from Application a"),
	@NamedQuery(name = "getApplicationsByStatus", query = "select a from Application a where "
			+ "a.applicationStatus= :applicationStatus") })
@Table(name="Applications")
public class Application {

	@Id
	@Column(name = "application_id", nullable = false, length = 6)
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "APPC_SQ")
	@SequenceGenerator(sequenceName = "APPLICATION_SEQUENCE", allocationSize = 1, name = "APPC_SQ")
	private Long applicationId;
	
	@Column(name = "Application_status", nullable = false)
	@Enumerated(EnumType.STRING)
	private ApplicationStatus applicationStatus;
	
	@Column(name = "Application_Date", nullable = false)
	private LocalDate applicationDate;
	
	@Column(name = "Remarks")
	private String remarks;
	
	@Column(name = "assigned_banker")
	private Integer assignedBanker;
	
	@Enumerated(EnumType.STRING)
	@Column(name = "account_type", nullable = false)
	private AccountType accountType;	
		
	@OneToOne
	@JoinColumn(name="p_apptId")
	private Applicant primaryApplicant;
	
	@OneToOne
	@JoinColumn(name="s_apptId")
	private Applicant secondaryApplicant;

	public Long getApplicationId() {
		return applicationId;
	}

	public void setApplicationId(Long applicationId) {
		this.applicationId = applicationId;
	}

	public ApplicationStatus getApplicationStatus() {
		return applicationStatus;
	}

	public void setApplicationStatus(ApplicationStatus applicationStatus) {
		this.applicationStatus = applicationStatus;
	}

	public LocalDate getApplicationDate() {
		return applicationDate;
	}

	public void setApplicationDate(LocalDate applicationDate) {
		this.applicationDate = applicationDate;
	}

	public String getRemarks() {
		return remarks;
	}

	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}

	public Integer getAssignedBanker() {
		return assignedBanker;
	}

	public void setAssignedBanker(Integer assignedBanker) {
		this.assignedBanker = assignedBanker;
	}

	public AccountType getAccountType() {
		return accountType;
	}

	public void setAccountType(AccountType accountType) {
		this.accountType = accountType;
	}

	public Applicant getPrimaryApplicant() {
		return primaryApplicant;
	}

	public void setPrimaryApplicant(Applicant primaryApplicant) {
		this.primaryApplicant = primaryApplicant;
	}

	public Applicant getSecondaryApplicant() {
		return secondaryApplicant;
	}

	public void setSecondaryApplicant(Applicant secondaryApplicant) {
		this.secondaryApplicant = secondaryApplicant;
	}

	@Override
	public String toString() {
		return "Application [applicationId=" + applicationId + ", applicationStatus=" + applicationStatus
				+ ", applicationDate=" + applicationDate + ", remarks=" + remarks + ", assignedBanker=" + assignedBanker
				+ ", accountType=" + accountType + ", primaryApplicant=" + primaryApplicant + ", secondaryApplicant="
				+ secondaryApplicant + "]";
	}
	
	
	
	
}
