package com.cg.ibs.investment.model;


import com.cg.ibs.investment.bean.MutualFund;

public class SipData {
	private Integer mfPlanId;
	private MutualFund mutualFund;
	public Integer getMfPlanId() {
		return mfPlanId;
	}
	public void setMfPlanId(Integer mfPlanId) {
		this.mfPlanId = mfPlanId;
	}
	public MutualFund getMutualFund() {
		return mutualFund;
	}
	public void setMutualFund(MutualFund mutualFund) {
		this.mutualFund = mutualFund;
	}
	
	

}
