package com.cg.ibs.investment.controller;

import java.util.ArrayList;
import java.util.HashMap;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cg.ibs.investment.bean.BankMutualFund;
import com.cg.ibs.investment.bean.Banker;
import com.cg.ibs.investment.exception.IBSException;
import com.cg.ibs.investment.service.BankService;
import com.cg.ibs.investment.service.CustomerService;
import com.cg.ibs.investment.model.Output;
import com.cg.ibs.investment.model.Units;
import com.cg.ibs.investment.model.User;

import antlr.collections.List;

@RestController
@CrossOrigin
@RequestMapping("/bank")
public class BankController {
	
	@Autowired
	private CustomerService customerService;
	@Autowired
	private BankService bankService;
	
	@PostMapping("/bankLogin")
	public ResponseEntity<Output> bankLogin(@RequestBody User user) throws IBSException{
		Boolean status = null;
		Output output=new Output();
		ResponseEntity<Output> entity=new ResponseEntity<Output>(HttpStatus.BAD_REQUEST);
		
			status = bankService.validateBank(user.getUserId(),user.getPassword());
			if(status) {
				output.setBool(true);
				output.setMsg("Welcome");
				entity= new ResponseEntity<Output>(output,HttpStatus.OK);
			}else {
				output.setBool(false);
				output.setMsg("Invalid Username or Password");
				entity=new ResponseEntity<>(output,HttpStatus.UNAUTHORIZED);
			}
		
		return entity;
	}
	
	@GetMapping("/viewGPrice")
	public ResponseEntity<Units> viewGPrice() throws IBSException{
		ResponseEntity<Units> entity=new ResponseEntity<Units>(HttpStatus.BAD_REQUEST);
			Units units=new Units();
			units.setUnits(customerService.viewGoldPrice());
			entity= new ResponseEntity<>(units,HttpStatus.OK );
		
		return entity;
	}
	
	@GetMapping("/viewSPrice")
	public ResponseEntity<Units> viewSPrice() throws IBSException{
		ResponseEntity<Units> entity=new ResponseEntity<Units>(HttpStatus.BAD_REQUEST);
		Units units=new Units();
		units.setUnits(customerService.viewSilverPrice());
			entity= new ResponseEntity<>(units ,HttpStatus.OK );
		
		return entity;
	}
	
	@PutMapping("/updateGPrice")
	public ResponseEntity<Output> updateGPrice(@RequestBody Units units) throws IBSException{
		System.out.println(units);
		System.out.println(units.getUnits());
		ResponseEntity<Output> entity = null;
		Output output = new Output();
		
			Boolean result;
			result = bankService.updateGoldPrice(units.getUnits());
			if(result) {
				output.setMsg("Gold Price updated successfully");
				output.setBool(true);
				 entity = new ResponseEntity<Output>(output,HttpStatus.OK);
				 
			}else {
				output.setMsg("Gold Price is already updated today");
				output.setBool(false);
				entity =  new ResponseEntity<>(output,HttpStatus.OK);
			}
		
		return entity;
	}
	
	@PutMapping("/updateSPrice")
	public ResponseEntity<Output> updateSPrice(@RequestBody Units units) throws IBSException{
		ResponseEntity<Output> entity = null;
		Output output = new Output();
					Boolean result;
			result = bankService.updateSilverPrice(units.getUnits());
			if(result) {
				output.setMsg("Silver Price updated successfully");
				output.setBool(true);
				 entity = new ResponseEntity<Output>(output,HttpStatus.OK);
			}else {
				output.setMsg("Silver Price is already updated today");
				output.setBool(false);
				entity =  new ResponseEntity<Output>(output,HttpStatus.OK);
			}
		
		return entity;
	}

	@GetMapping("/viewMf")
	public ResponseEntity<ArrayList<BankMutualFund>> viewMf() throws IBSException{
		HashMap<Integer, BankMutualFund> mutualFunds = null;
		ArrayList<BankMutualFund> bklist=new ArrayList<BankMutualFund>();
		//ResponseEntity<HashMap<Integer, BankMutualFund>> entity=null;
		ResponseEntity<ArrayList<BankMutualFund>> entity2=null;
		
			mutualFunds = customerService.viewMFPlans();
			for (BankMutualFund bankMutualFund : mutualFunds.values()) {
				bklist.add(bankMutualFund);
			}
			entity2=new ResponseEntity<ArrayList<BankMutualFund>>(bklist, HttpStatus.OK);
			//entity=new ResponseEntity<HashMap<Integer,BankMutualFund>>(mutualFunds,HttpStatus.OK);
		
		return entity2;
	}
	
	@PostMapping("/addMf")
	public ResponseEntity<Output> addMf(@RequestBody BankMutualFund bankMutualFund) throws IBSException{
		ResponseEntity<Output> entity=new ResponseEntity<Output>(HttpStatus.BAD_REQUEST);
		Output output = new Output();
		
			bankService.addMF(bankMutualFund);
			output.setMsg("You successfully added a Mutual Fund");
			output.setBool(true);
			entity=new ResponseEntity<Output>(output, HttpStatus.OK);
		
		return entity;
	}
	@PutMapping("/updateNav")
	public ResponseEntity<Output> updateNav(@RequestBody Output output) throws IBSException{
		ResponseEntity<Output> entity=new ResponseEntity<Output>(HttpStatus.BAD_REQUEST);
		Output out = new Output();
		
			bankService.updateNav(output.getMfPlanId(), output.getAmt());
			out.setMsg("You successfully updated Nav of the Mutual Fund plan");
			out.setBool(true);
			entity=new ResponseEntity<Output>(out,HttpStatus.OK);
			
		
		return entity;
	}
	
	@PutMapping("/updateSipStatus")
	public ResponseEntity<Output> updateSipStatus(@RequestBody Output output) throws IBSException{
		ResponseEntity<Output> entity=new ResponseEntity<Output>(HttpStatus.BAD_REQUEST);
		Output out = new Output();
		
			bankService.updateSipStatus(output.getMfPlanId(), output.getBool());
			out.setBool(true);
			out.setMsg("You successfully updated SIP status of the selected Mutual Fund");
			entity= new ResponseEntity<Output>(out,HttpStatus.OK);
		
		return entity;
	}
	
	@PutMapping("/updateDirStatus")
	public ResponseEntity<Output> updateDirStatus(@RequestBody Output output) throws IBSException{
		ResponseEntity<Output> entity=new ResponseEntity<Output>(HttpStatus.BAD_REQUEST);
		Output out = new Output();
		
			bankService.updateDirStatus(output.getMfPlanId(), output.getBool());
			out.setBool(true);
			out.setMsg("You successfully updated DIR status of the selected Mutual Fund");
			entity=new ResponseEntity<Output>(out,HttpStatus.OK);
		
		return entity;
	}
	
	@PutMapping("/updateMinDirAmt")
	public ResponseEntity<Output> updateMinDirAmt(@RequestBody Output output) throws IBSException{
		ResponseEntity<Output> entity=new ResponseEntity<Output>(HttpStatus.BAD_REQUEST);
		Output out = new Output();
		
			bankService.updateMinDir(output.getMfPlanId(),output.getAmt());
			out.setMsg("You successfully updated minimum amount for Direct Investment for the selected Mutual Fund");
			out.setBool(true);
			entity=new ResponseEntity<Output>(out,HttpStatus.OK);
		
		return entity;
	}
	
	@PutMapping("/updateMinSipAmt")
	public ResponseEntity<Output> updateMinSipAmt(@RequestBody Output output) throws IBSException{
		ResponseEntity<Output> entity=new ResponseEntity<Output>(HttpStatus.BAD_REQUEST);
		Output out = new Output();
			bankService.updateMinSip(output.getMfPlanId(),output.getAmt());
			out.setMsg("You successfully updated minimum amount for SIP Investment for the selected Mutual Fund");
			out.setBool(true);
			entity=new ResponseEntity<Output>(out,HttpStatus.OK);
		
		return entity;
	}
	
	@PatchMapping("/removeMf")
	public ResponseEntity<Output> removeMf(@RequestBody Output output) throws IBSException{
		ResponseEntity<Output> entity=new ResponseEntity<Output>(HttpStatus.BAD_REQUEST);
		Output out = new Output();
		
			bankService.removeMF(output.getMfPlanId());
			out.setMsg("You successfully removed the Mutual Fund plan");
			out.setBool(true);
			entity=new ResponseEntity<Output>(out,HttpStatus.OK);
			
		
		return entity;
	}
	@ExceptionHandler(IBSException.class)
	public ResponseEntity<String> handleAdbException(IBSException exp) {
		return new ResponseEntity<String>(exp.getMessage(), HttpStatus.BAD_REQUEST);
	}

	@ExceptionHandler(Exception.class)
	public ResponseEntity<String> handleException(Exception exp) {
		return new ResponseEntity<String>(exp.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR);
	}
	
}
