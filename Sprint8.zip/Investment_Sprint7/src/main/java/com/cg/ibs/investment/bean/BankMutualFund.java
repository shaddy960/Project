package com.cg.ibs.investment.bean;

import java.io.Serializable;
import java.time.LocalDate;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="Bank_Mutual_Fund")
public class BankMutualFund implements Serializable {
	
	@Id
	@Column(name = "mf_plan_id")
	private Integer mfPlanId;
	@Column(name = "title")
	private String title;
	@Column(name="nav",precision = 2)
	private Double nav;
	@Column(name = "launch_date")
	private LocalDate launchDate;
	@Column(name= "min_amt_sip",precision = 2)
	private Double minAmtSip;
	@Column(name = "min_amt_dir",precision = 2)
	private Double minAmtDir;
	@Column(name = "dir_status")
	private Boolean dirStatus;
	@Column(name = "sip_status")
	private Boolean sipStatus;
	@Column(name = "expiry_date")
	private LocalDate expiryDate;

	public BankMutualFund() {
		super();
	}

	public Integer getMfPlanId() {
		return mfPlanId;
	}

	public void setMfPlanId(Integer mfPlanId) {
		this.mfPlanId = mfPlanId;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public Double getNav() {
		return nav;
	}

	public void setNav(Double nav) {
		this.nav = nav;
	}

	public LocalDate getLaunchDate() {
		return launchDate;
	}

	public void setLaunchDate(LocalDate launchDate) {
		this.launchDate = launchDate;
	}

	public Double getMinAmtSip() {
		return minAmtSip;
	}

	public void setMinAmtSip(Double minAmtSip) {
		this.minAmtSip = minAmtSip;
	}

	public Double getMinAmtDir() {
		return minAmtDir;
	}

	public void setMinAmtDir(Double minAmtDir) {
		this.minAmtDir = minAmtDir;
	}

	public LocalDate getExpiryDate() {
		return expiryDate;
	}

	public void setExpiryDate(LocalDate expiryDate) {
		this.expiryDate = expiryDate;
	}

	public Boolean getDirStatus() {
		return dirStatus;
	}

	public void setDirStatus(Boolean dirStatus) {
		this.dirStatus = dirStatus;
	}

	public Boolean getSipStatus() {
		return sipStatus;
	}

	public void setSipStatus(Boolean sipStatus) {
		this.sipStatus = sipStatus;
	}

}
