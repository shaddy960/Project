package com.cg.ibs.investment.controller;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.cg.ibs.investment.bean.Account;
import com.cg.ibs.investment.bean.BankMutualFund;
import com.cg.ibs.investment.bean.InvestmentBean;
import com.cg.ibs.investment.bean.InvestmentTransaction;
import com.cg.ibs.investment.bean.MFType;
import com.cg.ibs.investment.bean.MutualFund;
import com.cg.ibs.investment.bean.ViewInvestmentBean;
import com.cg.ibs.investment.exception.IBSException;
import com.cg.ibs.investment.model.DirectData;
import com.cg.ibs.investment.model.MutualView;
import com.cg.ibs.investment.model.SipData;
import com.cg.ibs.investment.model.Statement;
import com.cg.ibs.investment.model.TransactionView;
import com.cg.ibs.investment.model.Units;
import com.cg.ibs.investment.model.User;
import com.cg.ibs.investment.model.ViewAccount;
import com.cg.ibs.investment.model.WithdrawDir;

import com.cg.ibs.investment.service.CustomerService;

@RestController
@CrossOrigin
@RequestMapping("/customer")
public class CustomerController {
	private String userId = "user1";

	@Autowired
	private CustomerService customerService;

	@PostMapping("/login")
	public ResponseEntity<Statement> customerLogin(@RequestBody User user) throws IBSException {
		System.out.println(user.getUserId() + user.getPassword());
		ResponseEntity<Statement> responseEntity = new ResponseEntity<Statement>(HttpStatus.BAD_REQUEST);
		Statement statement = new Statement();
		
			if (customerService.validateCustomer(user.getUserId(), user.getPassword())) {
				statement.setBool(true);
				statement.setMsg("User Logged in");
				responseEntity = new ResponseEntity<Statement>(statement, HttpStatus.OK);
				// customerService.autoSip(userId);
			} else {
				statement.setBool(false);
				statement.setMsg("No Such User exists");
				responseEntity = new ResponseEntity<Statement>(statement, HttpStatus.BAD_REQUEST);

			}
		

		return responseEntity;
	}

	@GetMapping("/viewMyInvestment")
	public ResponseEntity<ViewInvestmentBean> viewMyInvestments() throws IBSException {

		ViewInvestmentBean invBean = new ViewInvestmentBean();
		List<MutualView> dirset = new ArrayList<MutualView>();
		List<MutualView> sipset = new ArrayList<MutualView>(); 
		Double amt=0.0;
		
			InvestmentBean bean = customerService.viewInvestments("user1");
			System.out.println(bean.getUCI());
			invBean.setUci(bean.getUCI());
			invBean.setAccountNumber(bean.getAccount().getAccNo());
			invBean.setGoldUnits(bean.getGoldunits());
			invBean.setBalance(bean.getAccount().getBalance());
			invBean.setSilverUnits(bean.getSilverunits());
			invBean.setGoldAsset(bean.getGoldunits()*customerService.viewGoldPrice());
			invBean.setSilverAsset(bean.getSilverunits()*customerService.viewSilverPrice());

			
			for (MutualFund mf : bean.getFunds()) {
			MutualView view=new MutualView();
				if (mf.getType() == MFType.DIRECT && mf.getStatus()==true) {
					view.setBuyDate(mf.getBuyDate());
					view.setMfAmount(mf.getMfUnits()*mf.getBankMutualFund().getNav());
					view.setMfUnits(mf.getMfUnits());
					view.setPlanName(mf.getBankMutualFund().getTitle());
					view.setFolioNumber(mf.getFolioNumber());
					amt=amt+mf.getMfUnits()*mf.getBankMutualFund().getNav();
					dirset.add(view);
					
				} else if(mf.getType()==MFType.SIP && mf.getStatus()==true) {
					view.setBuyDate(mf.getBuyDate());
					view.setMfAmount(mf.getMfAmount());
					view.setMfUnits(mf.getMfUnits());
					view.setPlanName(mf.getBankMutualFund().getTitle());
					view.setFolioNumber(mf.getFolioNumber());
					view.setDuration(mf.getDuration());
					view.setClosingDate(mf.getClosingDate());
					view.setFrequency(mf.getFrequency());
					view.setInstallments(mf.getInstallments());
					view.setNextInstallDate(mf.getNextInstallDate());
					view.setOpeningDate(mf.getOpeningDate());
					view.setStatus(mf.getStatus());
					amt=amt+mf.getMfUnits()*mf.getBankMutualFund().getNav();
					sipset.add(view);
				}
			}
			invBean.setDirFunds(dirset);
			invBean.setSipfunds(sipset);
			invBean.setMfAssest(amt);
			
			 
		
		return new ResponseEntity<ViewInvestmentBean>(invBean, HttpStatus.OK);
	}

	@PostMapping("/directInvest")
	public ResponseEntity<Statement> investDirect(@RequestBody DirectData data) throws IBSException {
		ResponseEntity<Statement> entity = new ResponseEntity<Statement>(HttpStatus.BAD_REQUEST);
		Statement statement = new Statement();
			statement.setMsg("Direct Investment Bought successfully");
			statement.setBool(true);
			customerService.investDirMF(data.getMfAmount(), userId, data.getMfPlanId());
			entity = new ResponseEntity<Statement>(statement, HttpStatus.OK);
		return entity;
	}

	@PostMapping("/buyGold")
	public ResponseEntity<Statement> buyGold(@RequestBody Units gUnits) throws IBSException{
		ResponseEntity<Statement> entity = new ResponseEntity<Statement>(HttpStatus.BAD_REQUEST);
		Statement st = new Statement();
		customerService.buyGold(gUnits.getUnits(), gUnits.getUserId());
			st.setBool(true);
			st.setMsg("You successfully completed your gold purchase");
			entity = new ResponseEntity<Statement>(st, HttpStatus.OK);
		return entity;
	}

	@PostMapping("/buySilver")
	public ResponseEntity<Statement> buySilver(@RequestBody Units sUnits) throws IBSException {
		ResponseEntity<Statement> entity = new ResponseEntity<Statement>(HttpStatus.BAD_REQUEST);
		Statement statement = new Statement();
			customerService.buySilver(sUnits.getUnits(), userId);
			statement.setMsg("You successfully completed your silver purchase");
			statement.setBool(true);
			entity = new ResponseEntity<Statement>(statement, HttpStatus.OK);
		return entity;
	}

	@PostMapping("/sellGold")
	public ResponseEntity<Statement> sellGold(@RequestBody Units gUnits) throws IBSException {
		ResponseEntity<Statement> entity = new ResponseEntity<Statement>(HttpStatus.BAD_REQUEST);
		Statement statement = new Statement();
			customerService.sellGold(gUnits.getUnits(), userId);
			statement.setMsg("You successfully sold your gold units");
			statement.setBool(true);
			entity = new ResponseEntity<Statement>(statement, HttpStatus.OK);
		return entity;
	}

	@PostMapping("/sellSilver")
	public ResponseEntity<Statement> sellSilver(@RequestBody Units sUnits) throws IBSException {
		ResponseEntity<Statement> entity = new ResponseEntity<Statement>(HttpStatus.BAD_REQUEST);
		Statement statement = new Statement();
			customerService.sellSilver(sUnits.getUnits(), userId);
			statement.setMsg("You successfully sold your silver units");
			statement.setBool(true);
			entity = new ResponseEntity<Statement>(statement, HttpStatus.OK);
		return entity;
	}

	@PostMapping("/investSipMf")
	public ResponseEntity<Statement> investSip( @RequestBody SipData sipdata
			) throws IBSException {
		ResponseEntity<Statement> entity = new ResponseEntity<Statement>(HttpStatus.BAD_REQUEST);
		Statement statement = new Statement();
			statement.setBool(true);
			statement.setMsg("You successfully invested in the Mutual fund");
			BankMutualFund bk= customerService.viewMFPlans().get(sipdata.getMfPlanId());
		MutualFund fund = sipdata.getMutualFund();
		fund.setBankMutualFund(bk);
			customerService.investSipMF(userId, fund);
			entity = new ResponseEntity<Statement>(statement, HttpStatus.OK);
		return entity;
	}

	@GetMapping("/viewSipMf")
	public ResponseEntity<List<BankMutualFund>> viewSIPMfPlans() throws IBSException {
		List<BankMutualFund> sipList = null;
		ResponseEntity<List<BankMutualFund>> entity = new ResponseEntity<List<BankMutualFund>>(HttpStatus.OK);
			HashMap<Integer, BankMutualFund> bkmap = customerService.viewMFPlans();
			List<BankMutualFund> bankList = new ArrayList<BankMutualFund>(bkmap.values());
			sipList = new ArrayList<BankMutualFund>();
			for (BankMutualFund bk : bankList) {
				if (bk.getSipStatus() == true) {
					sipList.add(bk);
				}
			}
			entity = new ResponseEntity<List<BankMutualFund>>(sipList, HttpStatus.OK);
		return entity;
	}

	@GetMapping("/viewTrans")
	public ResponseEntity<List<TransactionView>> viewTrans() throws IBSException {
		List<InvestmentTransaction> transList = new ArrayList<InvestmentTransaction>();
		List<TransactionView> transList1 = new ArrayList<TransactionView>();
		ResponseEntity<List<TransactionView>> entity = new ResponseEntity<List<TransactionView>>(
				HttpStatus.BAD_REQUEST);
			transList = customerService.getTransactions(userId);
			for(InvestmentTransaction trnx:transList) {
				TransactionView temp = new TransactionView();
				temp.setTransactionId(trnx.getTransactionId());
				
				temp.setAccountNumber(trnx.getAccount().getAccNo());
				temp.setPricePerUnits(trnx.getPricePerUnit());
				temp.setTransactionAmount(trnx.getTransactionAmount());
				temp.setTransactionBalance(trnx.getTrxBalance());
				temp.setTransactionDate(trnx.getTransactionDate());
				temp.setTransactionDescription(trnx.getTransactionDescription());
				temp.setTransactionMode(trnx.getTransactionMode());
				temp.setTransactionType(trnx.getTransactionType());
				temp.setUnits(trnx.getUnits());
				transList1.add(temp);
				
			}
			entity = new ResponseEntity<List<TransactionView>>(transList1, HttpStatus.OK);
		return entity;
	}

	@GetMapping("/viewDirectMf")
	public ResponseEntity<List<BankMutualFund>> viewDirMfplans() throws IBSException {
		List<BankMutualFund> dirList = null;
		ResponseEntity<List<BankMutualFund>> entity = new ResponseEntity<List<BankMutualFund>>(HttpStatus.OK);
		
			HashMap<Integer, BankMutualFund> bkmap = customerService.viewMFPlans();
			List<BankMutualFund> bankList = new ArrayList<BankMutualFund>(bkmap.values());
			dirList = new ArrayList<BankMutualFund>();
			for (BankMutualFund bk : bankList) {
				if (bk.getDirStatus() == true) {
					dirList.add(bk);
				}
			}
			System.out.println(dirList);
			entity = new ResponseEntity<List<BankMutualFund>>(dirList, HttpStatus.OK);
		
		return entity;
	}

	@PostMapping("/withdrawDirMf")
	public ResponseEntity<Statement> withdrawDirMf(@RequestBody WithdrawDir withdrawData ) throws IBSException {
		
		Statement statement = new Statement();
		ResponseEntity<Statement> entity = new ResponseEntity<Statement>(HttpStatus.BAD_REQUEST);
		customerService.withdrawDirMF(userId,withdrawData);
				statement.setMsg("Direct Mutual Fund successfully withdrawn");
				statement.setBool(true);
				
				entity = new ResponseEntity<Statement>(statement, HttpStatus.OK);
		
		return entity;
	}

	@PostMapping("/withdrawSipMf")
	public ResponseEntity<Statement> withdrawSipMf(@RequestBody WithdrawDir withdrawData) throws IBSException {
		String message = null;
		ResponseEntity<Statement> entity = new ResponseEntity<Statement>(HttpStatus.BAD_REQUEST);
		Statement statement = new Statement();
		Map<Integer, MutualFund> sipMap = new HashMap<Integer, MutualFund>();
			Set<MutualFund> mutual = customerService.viewInvestments(userId).getFunds();
			for (MutualFund mutualFund : mutual) {
				if (mutualFund.getType().compareTo(MFType.SIP) == 0) {
					sipMap.put(mutualFund.getFolioNumber(), mutualFund);
				}
			}
			if (sipMap.containsKey(withdrawData.getFolioNumber())) {
				customerService.withdrawSipMF(userId, sipMap.get(withdrawData.getFolioNumber()));
				statement.setMsg("SIP Mutual Fund successfully withdrawn");
				statement.setBool(true);
				
				
				entity = new ResponseEntity<Statement>(statement, HttpStatus.OK);
			} else {
				statement.setMsg("No such SIP exists");
				statement.setBool(false);
				entity = new ResponseEntity<Statement>(statement, HttpStatus.BAD_REQUEST);
			}
		return entity;
	}

	@PostMapping("/linkAccount")
	public ResponseEntity<Statement> linkAccount(@RequestBody Units units) throws IBSException {
		Statement statement = new Statement();
		ResponseEntity<Statement> entity = new ResponseEntity<Statement>(HttpStatus.BAD_REQUEST);
		statement.setMsg("Account Linked successfully");
		statement.setBool(true);
			
			customerService.linkMyAccount(units.getAccNo(), userId);
			entity = new ResponseEntity<Statement>(statement, HttpStatus.OK);
			System.out.println(units.getAccNo());
		return entity;
	}
	@GetMapping("/accountList")
	public ResponseEntity<List<ViewAccount>> getAccList(String userId) throws IBSException{
		ResponseEntity<List<ViewAccount>> entity=new ResponseEntity<List<ViewAccount>>(HttpStatus.BAD_REQUEST);
		List<Account> accounts=customerService.getAccountList(userId);
		List<ViewAccount> accounts2=new ArrayList<ViewAccount>();
		for(Account account:accounts) {
			ViewAccount viewAccount=new ViewAccount();
			viewAccount.setAccNum(account.getAccNo());
			viewAccount.setCurrentBalance(account.getBalance());
			accounts2.add(viewAccount);
		}
		entity=new ResponseEntity<List<ViewAccount>>( accounts2, HttpStatus.OK);
		return entity;
	}
	@ExceptionHandler(IBSException.class)
	public ResponseEntity<String> handleAdbException(IBSException exp) {
		return new ResponseEntity<String>(exp.getMessage(), HttpStatus.BAD_REQUEST);
	}

	@ExceptionHandler(Exception.class)
	public ResponseEntity<String> handleException(Exception exp) {
		return new ResponseEntity<String>(exp.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR);
	}
	

}
