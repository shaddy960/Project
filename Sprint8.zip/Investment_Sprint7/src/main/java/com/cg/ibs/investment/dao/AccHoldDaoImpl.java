package com.cg.ibs.investment.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.springframework.stereotype.Repository;

import com.cg.ibs.investment.bean.AccountHolding;

@Repository("accHoldDao")
public class AccHoldDaoImpl implements AccHoldDao {
	@PersistenceContext
	private EntityManager entityManager;

	
	public AccountHolding addAccountHold(AccountHolding accHold) {		
		entityManager.persist(accHold);
		return accHold;
	}

	public AccountHolding updateAccountHold(AccountHolding accHold) {
		
		return null;
	}

	public AccountHolding getAccountByAccNo(Long aHId) {
		
		return null;
	}

	public List<AccountHolding> getAllAccounts() {
		
		return null;
	}

	public boolean removeAccountHold(Long aHId) {
		// TODO Auto-generated method stub
		return false;
	}

}
