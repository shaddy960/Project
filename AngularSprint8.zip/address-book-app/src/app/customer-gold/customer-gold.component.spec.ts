import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CustomerGoldComponent } from './customer-gold.component';

describe('CustomerGoldComponent', () => {
  let component: CustomerGoldComponent;
  let fixture: ComponentFixture<CustomerGoldComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CustomerGoldComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CustomerGoldComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
