import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ErrorCustomerComponent } from './error-customer.component';

describe('ErrorCustomerComponent', () => {
  let component: ErrorCustomerComponent;
  let fixture: ComponentFixture<ErrorCustomerComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ErrorCustomerComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ErrorCustomerComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
