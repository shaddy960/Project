import { GoldPrice } from './units';

describe('GoldPrice', () => {
  it('should create an instance', () => {
    expect(new GoldPrice()).toBeTruthy();
  });
});
