export class Units{
    public units:Number;
    public accNo:Number;
    public userId:string;
}