import { BankLogin } from './bank-login';

describe('BankLogin', () => {
  it('should create an instance', () => {
    expect(new BankLogin()).toBeTruthy();
  });
});
