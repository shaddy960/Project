export class BankMutualFund{
    	
	public mfPlanId:Number;
	
	public title:String;
	
	public nav:Number;
	
	public launchDate:Date;
	
	public minAmtSip:Number;
	
        public minAmtDir:Number;
	
	public dirStatus:Boolean;
	
	public sipStatus:Boolean;
	
	public expiryDate:Date;
}