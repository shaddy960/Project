import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { BanklogoutComponent } from './banklogout.component';

describe('BanklogoutComponent', () => {
  let component: BanklogoutComponent;
  let fixture: ComponentFixture<BanklogoutComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ BanklogoutComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(BanklogoutComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
