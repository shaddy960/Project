import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ViewMfComponent } from './view-mf.component';

describe('ViewMfComponent', () => {
  let component: ViewMfComponent;
  let fixture: ComponentFixture<ViewMfComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ViewMfComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ViewMfComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
