import { Component, OnInit } from '@angular/core';
import { Statement } from '../model/statement';
import { Units } from '../model/units';
import { CustomerService } from '../service/customer.service';
import { Router } from '@angular/router';
import { BankServiceService } from '../service/bank-service.service';

@Component({
  selector: 'app-customer-silver',
  templateUrl: './customer-silver.component.html',
  styleUrls: ['./customer-silver.component.css']
})
export class CustomerSilverComponent implements OnInit {

  stmt: Statement;
  sUnits: Units;
  msg: String;
  sPrice:Number;
  constructor(private custServ: CustomerService, private router:Router,private bankService:BankServiceService) {
    this.stmt = new Statement();
    this.sUnits = new Units();


  }

  ngOnInit() {
    this.bankService.getSilverPrice().subscribe((data)=>{
      this.sPrice=data.units
          });

  }
  buy() {
    console.log("Here in buy");
    console.log(this.sUnits);
    this.custServ.buyCustSilver(this.sUnits).subscribe(
      (data) => {
        this.stmt = data;
        this.msg = data.msg;
        this.custServ.customerMessage=data.msg;
        if(this.stmt.bool){
          this.router.navigate(['/custDash']);
        }else{
          this.custServ.customerError=data.msg;
          this.router.navigate(['/errorCustomer']);
        }
        
      },
      (error)=>{
       this.custServ.customerError=error;
        this.router.navigate(['/errorCustomer']);
      }
    );
  }

  sell() {
    console.log("Here in Sell");
    console.log(this.sUnits);
    this.custServ.sellCustSilver(this.sUnits).subscribe(
      (data) => {
        this.stmt = data;
        this.msg = data.msg;
        this.custServ.customerMessage=data.msg;
        if(this.stmt.bool){
          this.router.navigate(['/custDash']);
        }else{
          this.custServ.customerError=data.msg;
          this.router.navigate(['/errorCustomer']);
        }
        
      },
      (error)=>{
       this.custServ.customerError=error;
        this.router.navigate(['/errorCustomer']);
      }
    );

  }
}
