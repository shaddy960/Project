import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { LinkMyAccountComponent } from './link-my-account.component';

describe('LinkMyAccountComponent', () => {
  let component: LinkMyAccountComponent;
  let fixture: ComponentFixture<LinkMyAccountComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ LinkMyAccountComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(LinkMyAccountComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
