import { Component, OnInit } from '@angular/core';
import { BankMutualFund } from '../model/bankmutualfund';
import { BankServiceService } from '../service/bank-service.service';
import { Router } from '@angular/router';
import { Statement } from '../model/statement';

@Component({
  selector: 'app-add-mf',
  templateUrl: './add-mf.component.html',
  styleUrls: ['./add-mf.component.css']
})
export class AddMfComponent implements OnInit {
  bankMut:BankMutualFund;
  msg:String;
  stmt:Statement;
  constructor(private banksrv:BankServiceService, private router:Router) {
    this.bankMut=new BankMutualFund();
    this.msg="";
    this.stmt=new Statement();
   }

  ngOnInit() {
  }
  save(){
    this.banksrv.addMf(this.bankMut).subscribe(
      (data)=>{
        this.msg=data.msg;
        this.banksrv.bankMessage=data.msg;
        this.stmt.bool=data.bool;
        if(this.stmt.bool){         
          this.router.navigate(['/Bank']);
        }else{
          this.banksrv.bankError=data.msg;
          this.router.navigate(['/errorBank']);
        }     
      },
      (err)=>{
        this.banksrv.bankError=err.msg;
        this.router.navigate(['/errorBank']);
      }

    );
  }
  onGoBack(){
    this.router.navigate(['/manageMf'])
  }

}
