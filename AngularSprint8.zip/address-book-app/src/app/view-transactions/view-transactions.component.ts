import { Component, OnInit } from '@angular/core';
import { CustomerService } from '../service/customer.service';
import { InvestmentTrans } from '../model/investmentTrans';
import { Route, Router } from '@angular/router';

@Component({
  selector: 'app-view-transactions',
  templateUrl: './view-transactions.component.html',
  styleUrls: ['./view-transactions.component.css']
})
export class ViewTransactionsComponent implements OnInit {
  invTr:InvestmentTrans[];
  constructor(private custSrv:CustomerService, private router: Router) {
    this.invTr=[];
   }

  ngOnInit() {
    this.getAllInvTr();
  }
  getAllInvTr(){
    this.custSrv.getAllTrans().subscribe(
      (data)=>{
        this.invTr=data;
      }
   
    ,(error)=>{
     this.custSrv.customerError=error;
      this.router.navigate(['/errorCustomer']);
    }
    );
  }

}
