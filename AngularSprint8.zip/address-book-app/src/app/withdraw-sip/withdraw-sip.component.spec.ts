import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { WithdrawSipComponent } from './withdraw-sip.component';

describe('WithdrawSipComponent', () => {
  let component: WithdrawSipComponent;
  let fixture: ComponentFixture<WithdrawSipComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ WithdrawSipComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(WithdrawSipComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
