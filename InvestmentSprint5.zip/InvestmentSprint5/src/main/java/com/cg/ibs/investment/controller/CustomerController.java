package com.cg.ibs.investment.controller;

import java.math.BigInteger;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map.Entry;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.cg.ibs.investment.bean.BankMutualFund;
import com.cg.ibs.investment.bean.CustomerBean;
import com.cg.ibs.investment.bean.Frequency;
import com.cg.ibs.investment.bean.GoldPrice;
import com.cg.ibs.investment.bean.InvestmentBean;
import com.cg.ibs.investment.bean.MFType;
import com.cg.ibs.investment.bean.MutualFund;
import com.cg.ibs.investment.exception.IBSException;
import com.cg.ibs.investment.service.CustomerService;

@Controller
public class CustomerController {
	private String userId = "user1";

	@Autowired
	private CustomerService service;

	@RequestMapping("/customer")
	public ModelAndView showDeptsHome() {
		return new ModelAndView("customerLogin");
	}

	@RequestMapping("/custLogin")
	public ModelAndView customerLogin(@RequestParam("userId") String userId,
			@RequestParam("password") String password) {
		ModelAndView modelAndView = new ModelAndView();
		try {
		if (service.validateCustomer(userId, password)) {	
			modelAndView.addObject("price", service.viewGoldPrice());
			modelAndView.addObject("sprice", service.viewSilverPrice());
			modelAndView.setViewName("customerMenu");
		}else {
			String msg="No Such User exists";
			modelAndView.addObject("message",msg);
			modelAndView.setViewName("errorPage");
		}} catch (IBSException e) {
			String msg="No Such User exists";
			modelAndView.addObject("message",msg);
			modelAndView.setViewName("errorPage");
		}
		return modelAndView;
	}

	@RequestMapping("/viewMyInvestment")
	public ModelAndView viewMyInvestments() {
		ModelAndView mv = new ModelAndView();
		Set<MutualFund> dirset = new HashSet<MutualFund>();
		Set<MutualFund> sipset = new HashSet<MutualFund>();
		try {
			InvestmentBean bean = service.viewInvestments(userId);
			mv.addObject("uci", bean.getUCI());
			mv.addObject("goldunits", bean.getGoldunits());
			mv.addObject("silverunits", bean.getSilverunits());
			for (MutualFund mf : bean.getFunds()) {
				if (mf.getType() == MFType.DIRECT) {
					dirset.add(mf);
				} else {
					sipset.add(mf);
				}
			}
			mv.addObject("directMf", dirset);
			mv.addObject("sipmf", sipset);
		} catch (IBSException e) {
			mv.addObject("message",e.getMessage());
			mv.setViewName("errorPage");
		}
		mv.setViewName("viewMyInvestment");
		return mv;
	}

	@RequestMapping("/viewMyTransactions")
	public ModelAndView viewMyTransactions() {
		ModelAndView mv = new ModelAndView();
		try {
			mv.addObject("transactions", service.getTransactions(userId));
			mv.setViewName("viewMyTransactions");
		} catch (IBSException e) {
			mv.addObject("message",e.getMessage());
			mv.setViewName("errorPage");
		}
		
		return mv;
	}
	@RequestMapping("/Gold")
	public ModelAndView buyGold() {
		ModelAndView mv = new ModelAndView();
		try {
			mv.addObject("price", service.viewGoldPrice());
		} catch (IBSException e) {
		}
		mv.setViewName("GoldPage");
		return mv;
	}

	@RequestMapping("/buygold")
	public ModelAndView buyGoldMethod(@RequestParam("goldUnits") Double goldUnits) {
		ModelAndView mv=new ModelAndView();
		try {
			service.buyGold(goldUnits, userId);
			 mv.setViewName("customerMenu");
		} catch (IBSException e) {
			mv.addObject("message",e.getMessage());
			mv.setViewName("errorPage");
		}
		return mv;
	}

	@RequestMapping("/sellgold")
	public ModelAndView sellGoldMethod(@RequestParam("goldUnits") Double goldUnits) {
		ModelAndView mv=new ModelAndView();
		try {
			service.sellGold(goldUnits, userId);
			mv.setViewName("customerMenu");
		} catch (IBSException e) {
			mv.addObject("message",e.getMessage());
			mv.setViewName("errorPage");
		}
		return new ModelAndView("customerMenu");
	}

	@RequestMapping("/Silver")
	public ModelAndView buySilver() {
		ModelAndView mv = new ModelAndView();
		try {
			mv.addObject("price", service.viewSilverPrice());
		} catch (IBSException e) {
		}
		mv.setViewName("SilverPage");
		return mv;
	}

	@RequestMapping("/silverbuy")
	public ModelAndView buySilverMethod(@RequestParam("silverUnits") Double silverUnits) {
		ModelAndView mv=new ModelAndView();
		try {
			service.buySilver(silverUnits, userId);
			mv.setViewName("customerMenu");
		} catch (IBSException e) {
			mv.addObject("message",e.getMessage());
			mv.setViewName("errorPage");
		}
		return mv;
	}

	@RequestMapping("/silversell")
	public ModelAndView sellSilverMethod(@RequestParam("silverUnits") Double silverUnits) {
		ModelAndView mv=new ModelAndView();
		try {
			service.sellSilver(silverUnits, userId);
			mv.setViewName("customerMenu");
		} catch (IBSException e) {
			mv.addObject("message",e.getMessage());
			mv.setViewName("errorPage");
		}
		return mv;
	}

	@RequestMapping("/investDirect")
	public ModelAndView investDirectMf() {
		ModelAndView mv = new ModelAndView();
		try {
			HashMap<Integer, BankMutualFund> bkmap = service.viewMFPlans();
			List<BankMutualFund> bankList = new ArrayList<BankMutualFund>(bkmap.values());
			List<BankMutualFund> dirList = new ArrayList<BankMutualFund>();
			for (BankMutualFund bk : bankList) {
				if (bk.getDirStatus() == true) {
					dirList.add(bk);
					mv.addObject("dirList", dirList);
					mv.setViewName("investDirectForm");
				} else {
					System.out.println("DirectFailed");
				}
			}
		} catch (IBSException e) {
			mv.addObject("message", e.getMessage());
			mv.setViewName("errorPage");
		}
		return mv;
	}

	@RequestMapping("/directInvest")
	public ModelAndView investDirect(@RequestParam("mfPlanId") int mfPlanId,
			@RequestParam("mfAmount") Double mfAmount) {
		ModelAndView mv=new ModelAndView();
		try {
			service.investDirMF(mfAmount, userId, mfPlanId);
			mv.setViewName("customerMenu");
		} catch (IBSException e) {
			mv.addObject("message",e.getMessage());
			mv.setViewName("errorPage");
		}
		return mv;
	}

	@RequestMapping("/investSip")
	public ModelAndView investSipMf() {
		ModelAndView mv = new ModelAndView();
		try {
			HashMap<Integer, BankMutualFund> bkmap = service.viewMFPlans();
			List<BankMutualFund> bankList = new ArrayList<BankMutualFund>(bkmap.values());
			List<BankMutualFund> sipList = new ArrayList<BankMutualFund>();
			for (BankMutualFund bk : bankList) {
				if (bk.getSipStatus() == true) {
					sipList.add(bk);
					mv.addObject("sipList", sipList);
					mv.setViewName("investSipForm");
				} else {
					System.out.println("SipFailed");
				}
			}
		} catch (IBSException e) {
			mv.addObject("message",e.getMessage());
			mv.setViewName("errorPage");
		}
		return mv;
	}

	@RequestMapping("/sipInvest")
	public ModelAndView investSip(@RequestParam("mfPlanId") int mfPlanId, @RequestParam("frequency") String frequency,
			@RequestParam("duration") int duration, @RequestParam("mfAmount") Double mfAmount,
			@RequestParam("date") String date1) {
		ModelAndView mv=new ModelAndView();
		MutualFund fund = new MutualFund();
		DateTimeFormatter formatter = DateTimeFormatter.ISO_DATE;
		try {
			BankMutualFund fund2 = service.viewMFPlans().get(mfPlanId);
			fund.setBankMutualFund(fund2);
			fund.setFrequency(Frequency.valueOf(frequency));
			fund.setDuration(duration);
			fund.setMfAmount(mfAmount);
			fund.setOpeningDate(LocalDate.parse(date1, formatter));
			service.investSipMF(userId, fund);
			mv.setViewName("customerMenu");
		} catch (IBSException e) {
			mv.addObject("message",e.getMessage());
			mv.setViewName("errorPage");
		}
		return mv;
	}

	@RequestMapping("/viewMfPlans")
	public ModelAndView viewMfPlans() {
		ModelAndView mv = new ModelAndView("MfviewMenu");
		return mv;
	}

	@RequestMapping("/SIPCust")
	public ModelAndView viewSIPMfPlans() {
		ModelAndView mv = new ModelAndView();
		try {
			HashMap<Integer, BankMutualFund> bkmap = service.viewMFPlans();
			List<BankMutualFund> bankList = new ArrayList<BankMutualFund>(bkmap.values());
			List<BankMutualFund> sipList = new ArrayList<BankMutualFund>();
			for (BankMutualFund bk : bankList) {
				if (bk.getSipStatus() == true) {
					sipList.add(bk);
					mv.addObject("sipList", sipList);
					mv.setViewName("viewSipMF");
				} else {
					System.out.println("SipFailed");
				}
			}
		} catch (IBSException e) {
			mv.addObject("message",e.getMessage());
			mv.setViewName("errorPage");
		}
		return mv;
	}

	@RequestMapping("/DIRECTCust")
	public ModelAndView viewDirectMfPlans() {
		ModelAndView mv = new ModelAndView();
		try {
			HashMap<Integer, BankMutualFund> bkmap = service.viewMFPlans();
			List<BankMutualFund> bankList = new ArrayList<BankMutualFund>(bkmap.values());
			List<BankMutualFund> sipList = new ArrayList<BankMutualFund>();
			for (BankMutualFund bk : bankList) {
				if (bk.getDirStatus() == true) {
					sipList.add(bk);
					mv.addObject("sipList", sipList);
					mv.setViewName("viewDirMF");
				} else {
					System.out.println("DirectFailed");
				}
			}
		} catch (IBSException e) {
			mv.addObject("message",e.getMessage());
			mv.setViewName("errorPage");
		}
		return mv;
	}

	@RequestMapping("/BothCust")
	public ModelAndView viewBothMfPlans() {
		ModelAndView mv = new ModelAndView();
		try {
			HashMap<Integer, BankMutualFund> bkmap = service.viewMFPlans();
			List<BankMutualFund> bankList = new ArrayList<BankMutualFund>(bkmap.values());
			List<BankMutualFund> sipList = new ArrayList<BankMutualFund>();
			for (BankMutualFund bk : bankList) {
				if (bk.getDirStatus() == true && bk.getSipStatus() == true) {
					sipList.add(bk);
					mv.addObject("sipList", sipList);
					mv.setViewName("viewMF");
				} else {
					System.out.println("BothFailed");
				}
			}
		} catch (IBSException e) {
			mv.addObject("message",e.getMessage());
			mv.setViewName("errorPage");
		}
		return mv;
	}

	@RequestMapping("/withdrawMf")
	public ModelAndView withdrawMf() {
		ModelAndView mv = new ModelAndView();
		try {
			List<MutualFund> InvestmentList = new ArrayList<>(service.viewInvestments(userId).getFunds());
			List<MutualFund> openinvestmentList = new ArrayList<>();
			for (int i = 0; i < InvestmentList.size(); i++) {
				if (InvestmentList.get(i).getClosingDate() == null) {

					openinvestmentList.add(InvestmentList.get(i));
				}
			}
			mv.addObject("openinvestmentList", openinvestmentList);
			mv.setViewName("withdrawMutual");
		} catch (IBSException e) {
			mv.addObject("message",e.getMessage());
			mv.setViewName("errorPage");
		}
		return mv;
	}

	@RequestMapping(value = "/withdraw", method = RequestMethod.GET)
	public ModelAndView withdrawFunction(@RequestParam("folioNumber") Integer folioNum) {
		ModelAndView mv=new ModelAndView();
		try {
			Set<MutualFund> mutual = service.viewInvestments(userId).getFunds();
			for (MutualFund mutualFund : mutual) {
				if (mutualFund.getFolioNumber().compareTo(folioNum)==0) {
					if (mutualFund.getType() == MFType.DIRECT) {
						service.withdrawDirMF(userId, mutualFund);
						
					} else {
						service.withdrawSipMF(userId, mutualFund);
					}
				}
			}
			mv.setViewName("customerMenu");
		} catch (IBSException e) {
			mv.addObject("message",e.getMessage());
			mv.setViewName("errorPage");
		}

		return mv;
	}
	@RequestMapping("/linkMyAccount")
	public ModelAndView linkAccount(){
		ModelAndView mv = new ModelAndView();
		try {
			mv.addObject("accountList",service.getAccountList(userId));
			mv.setViewName("linkAccount");
		} catch (IBSException e) {
			mv.addObject("message",e.getMessage());
			mv.setViewName("errorPage");
		}
		
		return mv;
	}
	@RequestMapping("/link")
	public ModelAndView linkMyAccount(@RequestParam("accNo") BigInteger accNo) {
		ModelAndView mv=new ModelAndView();
		try {
			service.linkMyAccount(accNo, userId);
			mv.setViewName("customerMenu");
		} catch (IBSException e) {
			mv.addObject("message",e.getMessage());
			mv.setViewName("errorPage");
		}
		return mv;
	}
}