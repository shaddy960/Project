import { Injectable } from '@angular/core';
import { HttpClient, HttpErrorResponse, HttpResponse } from '@angular/common/http';
import { environment } from 'src/environments/environment';
import { Observable, throwError  } from 'rxjs';
import {catchError} from 'rxjs/operators';
import { Api } from '../model/api';

@Injectable({
  providedIn: 'root'
})
export class ApiserviceService {

  baseUrl:string;
  name:String;
  constructor(private http:HttpClient) { 
    this.baseUrl =`${environment.baseMwUrl}/api`;
    this.name="";
  }

  getAllApis():Observable<Api[]>{
    return this.http.get<Api[]>(`${this.baseUrl}/getAll`).pipe(catchError(this.errorHandler));
  }
  getAllNames():Observable<String[]>{
    return this.http.get<String[]>(`${this.baseUrl}/getNames`).pipe(catchError(this.errorHandler));
  }
  getApi(name1:String):Observable<Api[]>{
    
    name1=this.name;
    return this.http.get<Api[]>(`${this.baseUrl}/getA/${name1}`).pipe(catchError(this.errorHandler));
  }

  errorHandler(error:HttpErrorResponse){
    if (error.error instanceof ErrorEvent) {
      // A client-side or network error occurred. Handle it accordingly.
      console.error('An error occurred:', error.error);
    } else {
     
      // The backend returned an unsuccessful response code.
      // The response body may contain clues as to what went wrong,
      console.error(
        `Backend returned code ${error.status}, ` +
        `body was: ${error.error}`);
    }
    // return an observable with a user-facing error message
    return throwError(
      error.error);
  }
}
