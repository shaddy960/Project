export class Api{
    public name:String;
	public url:String;
	public status:String;
	public args:Number;
	public description:String;
	public returnType:String;
	public func:String;
}