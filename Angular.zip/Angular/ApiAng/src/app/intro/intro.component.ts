import { Component, OnInit } from '@angular/core';
import { Api } from '../model/api';
import { ApiserviceService } from '../service/apiservice.service';
import { Router } from '@angular/router';
import { FormControl } from '@angular/forms';
import {Observable} from 'rxjs';
import {map, startWith} from 'rxjs/operators';


@Component({
  selector: 'app-intro',
  templateUrl: './intro.component.html',
  styleUrls: ['./intro.component.css']
})
export class IntroComponent implements OnInit {
  sumit:String;
  name=new FormControl('');
  nameU:String;
  apiList:Api[];
  names:String[];
  filteredNames: Observable<String[]>;
  constructor(private apiSer:ApiserviceService, private router:Router) {
    this.names=[];
    this.sumit="hellow";
    this.nameU="";
   }

  ngOnInit() {
    this.apiSer.getAllApis().subscribe(
      (data)=>{
        this.apiList=data;
      }
    );
    this.apiSer.getAllNames().subscribe(
      (data)=>{
        this.names=data;
      }
    );
    this.filteredNames= this.name.valueChanges
    .pipe(
      startWith(''),
      map(value => this.namefilter(value))
    );
  }

  private namefilter(value: String): String[] {
     const filterValue = value.toLowerCase();

    return this.names.filter(option => option.toLowerCase().startsWith(filterValue));
  }

  getApi(){
    console.log(this.nameU);
    this.apiSer.name=this.nameU;
    this.apiSer.getApi(this.nameU).subscribe(
      (data)=>{
        this.apiList=data;
      }
    );
  }

  
  

 

}
