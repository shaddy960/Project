package com.cg;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collector;
import java.util.stream.Collectors;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@CrossOrigin
@RequestMapping("/api")
public class ApiController {
	
	@GetMapping("/getAll")
	public ResponseEntity<List<Api>> getAllApi() throws IOException{
		ResponseEntity<List<Api>> entity=new ResponseEntity<>(HttpStatus.BAD_REQUEST);
		
			FileInputStream file = new FileInputStream(new File("C://Users//SHASONI//Downloads/RESTful API'S.xlsx"));

			List<Api> apiList = new ArrayList<>();
			// Create Workbook instance holding reference to .xlsx file
			XSSFWorkbook workbook = new XSSFWorkbook(file);

			// Get first/desired sheet from the workbook
			XSSFSheet sheet = workbook.getSheetAt(0);

			// Iterate through each rows one by one
			Iterator<Row> rowIterator = sheet.iterator();

			while (rowIterator.hasNext()) {
				Row row = rowIterator.next();
				// For each row, iterate through all the columns
				Iterator<Cell> cellIterator = row.cellIterator();
				Api api=new Api();
				if (row.getRowNum() > 3) {
					while (cellIterator.hasNext()) {
						
						Cell cell = cellIterator.next();
						// Check the cell type and format accordingly
						switch (cell.getColumnIndex()) 
	                    {
	                       
	                        case 0:
	                           
	                            api.setName(cell.getStringCellValue());
	                            break;
	                        case 1:
	                           
	                            api.setUrl(cell.getStringCellValue());
	                            break;
	                        case 2:
	                            
	                            api.setStatus(cell.getStringCellValue());
	                            break;
	                        case 3:
	                            
	                            api.setArgs(cell.getNumericCellValue());
	                            break;
	                        case 4:
	                            
	                            api.setDescription(cell.getStringCellValue());
	                            break;
	                        case 5:
	                           
	                            api.setReturnType(cell.getStringCellValue());
	                            break;
	                        case 6:
	                           
	                            api.setFunc(cell.getStringCellValue());
	                            break;
	                    }
						
					}
					apiList.add(api);
				} else {
					//System.out.println("RowElse");
				}
			}
			entity=new ResponseEntity<List<Api>>(apiList, HttpStatus.OK);
			
			file.close();
			
		
		
		return entity;
	}
	@GetMapping("/getNames")
	public ResponseEntity<Set<String>> getAllNames() throws IOException{
		ResponseEntity<Set<String>> entity=new ResponseEntity<Set<String>>(HttpStatus.BAD_REQUEST);
		ApiController controller=new ApiController();
		
		List<Api> list=controller.getAllApi().getBody();
		Set<String> nameSet=new HashSet<>();
		for (Api api : list) {
			if(!nameSet.contains(api.getName())) {
				nameSet.add(api.getName());
			}else {
				//System.out.println(api.getName()+" Yoo");
			}
			
		}
		entity=new  ResponseEntity<Set<String>>(nameSet,HttpStatus.OK);
		
		return entity;
	}
	
	@GetMapping("/getA/{name}")
	public ResponseEntity<List<Api>> getApi(@PathVariable("name") String name) throws IOException{
		
		ResponseEntity<List<Api>> entity=new ResponseEntity<List<Api>>(HttpStatus.BAD_REQUEST);
		List<Api> apis=getAllApi().getBody();
		List<Api> apiN=new ArrayList<Api>();
		for (Api api : apis) {
			if(api.getName().equals(name)) {
				apiN.add(api);
			}else {
				//System.out.println(api.getName());
			}
		}
	
		entity=new ResponseEntity<List<Api>>(apiN,HttpStatus.OK);
		
		
		return entity;
	}
	@ExceptionHandler(IOException.class)
	public ResponseEntity<String> handleAdbException(IOException exp) {
		return new ResponseEntity<String>(exp.getMessage(), HttpStatus.BAD_REQUEST);
	}

	@ExceptionHandler(Exception.class)
	public ResponseEntity<String> handleException(Exception exp) {
		return new ResponseEntity<String>(exp.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR);
	}
}
