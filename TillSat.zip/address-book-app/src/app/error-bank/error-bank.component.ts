import { Component, OnInit } from '@angular/core';
import { BankServiceService } from '../service/bank-service.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-error-bank',
  templateUrl: './error-bank.component.html',
  styleUrls: ['./error-bank.component.css']
})
export class ErrorBankComponent implements OnInit {
  message:String;
  constructor(private bankSrv:BankServiceService, private router:Router) {

   }

  ngOnInit() {
        this.message=this.bankSrv.bankError;
  }

}
