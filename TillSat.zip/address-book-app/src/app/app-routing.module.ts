import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import {DashboardComponent} from './dashboard/dashboard.component';
import {GroupsComponent} from './groups/groups.component';
import {ContactFormComponent} from './contact-form/contact-form.component';
import {SearchContactComponent} from './search-contact/search-contact.component';
import {ContactsListComponent} from './contacts-list/contacts-list.component';

import { from } from 'rxjs';
import { CustomerDashboardComponent } from './customer-dashboard/customer-dashboard.component';
import { ViewinvestmentsComponent } from './viewinvestments/viewinvestments.component';
import { ViewTransactionsComponent } from './view-transactions/view-transactions.component';
import { CustomerGoldComponent } from './customer-gold/customer-gold.component';
import { CustomerSilverComponent } from './customer-silver/customer-silver.component';
import { WithdrawMFComponent } from './withdraw-mf/withdraw-mf.component';
import { LinkMyAccountComponent } from './link-my-account/link-my-account.component';
import { InvestDirectComponent } from './invest-direct/invest-direct.component';
import { InvestSIPComponent } from './invest-sip/invest-sip.component';
import { WithdrawSipComponent } from './withdraw-sip/withdraw-sip.component';
import { WithdrawDirComponent } from './withdraw-dir/withdraw-dir.component';
import { LoginComponent } from './login/login.component';
import {BankLoginComponent} from './bank-login/bank-login.component';
import {BankMenuComponent} from './bank-menu/bank-menu.component';
import { ManageGoldComponent } from './manage-gold/manage-gold.component';
import { ManageSilverComponent } from './manage-silver/manage-silver.component';
import { ManageMfComponent } from './manage-mf/manage-mf.component';
import { ViewMfComponent } from './view-mf/view-mf.component';
import { UpdateNavComponent } from './update-nav/update-nav.component';

import { UpdateDirStatusComponent } from './update-dir-status/update-dir-status.component';
import { UpdateSipStatusComponent } from './update-sip-status/update-sip-status.component';
import { UpdateMinAmtDirComponent } from './update-min-amt-dir/update-min-amt-dir.component';
import { UpdateMinAmtSipComponent } from './update-min-amt-sip/update-min-amt-sip.component';
import { ErrorBankComponent } from './error-bank/error-bank.component';
import { ErrorCustomerComponent } from './error-customer/error-customer.component';
import { RemoveMfComponent } from './remove-mf/remove-mf.component';
import { AddMfComponent } from './add-mf/add-mf.component';






const routes: Routes = [
  {path:'',component:DashboardComponent,pathMatch:'full'},
  {path:'customerLogin',component:LoginComponent},
  {path:'bankLogin',component:BankLoginComponent},
  {path:'groups',component:GroupsComponent},
  {path:'contacts',component:ContactsListComponent},
  {path:'newContact',component:ContactFormComponent},
  {path:'editContact/:contactId',component:ContactFormComponent},
  {path:'search',component:SearchContactComponent},
  {path:'custDash',component:CustomerDashboardComponent},
  {path:'viewInvestment',component:ViewinvestmentsComponent},
  {path:'viewTransactions',component:ViewTransactionsComponent},
  {path:'custGold',component:CustomerGoldComponent},
  {path:'custSil',component:CustomerSilverComponent},
  {path:'withdraw',component:WithdrawMFComponent},
  {path:'linkMyacc',component:LinkMyAccountComponent},
  {path:'investDirect',component:InvestDirectComponent},
  {path:'investSip',component:InvestSIPComponent},
  {path:'withdrawDir',component:WithdrawDirComponent},
  {path:'withdrawSip',component: WithdrawSipComponent},
  {path: 'removeMf', component: RemoveMfComponent},
  {path:'manageSilver',component:ManageSilverComponent},
  {path:'manageGold',component:ManageGoldComponent},
  {path:'manageMf',component:ManageMfComponent},
  {path:'Bank',component:BankMenuComponent},
  {path:'errorBank',component:ErrorBankComponent},
  {path:'viewMf',component:ViewMfComponent},
  {path:'updateDirStatus',component:UpdateDirStatusComponent},
  {path:'updateSipStatus',component:UpdateSipStatusComponent},
  {path:'updateMinAmtDir',component:UpdateMinAmtDirComponent},
  {path:'updateMinAmtSip',component:UpdateMinAmtSipComponent},
  {path:'updateNav',component:UpdateNavComponent},
  {path:'errorCustomer',component:ErrorCustomerComponent},
  {path:'bankMenu',component:BankMenuComponent},
  {path:'addMf',component:AddMfComponent},


];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
