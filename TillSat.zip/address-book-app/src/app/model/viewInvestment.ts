import { MutualFund } from './mutualfund';

export class ViewInvestment{
    public uci:Number;
    public goldUnits:Number;
    public silverUnits:Number;
    public sipfunds:MutualFund[];
    public dirFunds:MutualFund[];
    public accountNumber:Number;
    public balance:Number;
    public silverAsset:Number;
    public goldAsset:Number;
    public mfAssest:Number;
}