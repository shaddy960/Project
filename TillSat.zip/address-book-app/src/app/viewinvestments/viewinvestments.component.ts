import { Component, OnInit } from '@angular/core';
import { ViewInvestment } from '../model/viewInvestment';
import { CustomerService } from '../service/customer.service';
import {MutualFund} from '../model/mutualfund';
import { Router } from '@angular/router';

@Component({
  selector: 'app-viewinvestments',
  templateUrl: './viewinvestments.component.html',
  styleUrls: ['./viewinvestments.component.css']
})
export class ViewinvestmentsComponent implements OnInit {
  num:Number;
  viewInv:ViewInvestment;
  DirFunds: MutualFund[];
  SIPFunds: MutualFund[];
  constructor(private custServ:CustomerService, private router:Router) {
    this.viewInv=new ViewInvestment();
 
   }

  ngOnInit() {
    this.load();
  }
  load() {
    this.custServ.getInv().subscribe(
      (data) => {
        this.viewInv = data;
        this.DirFunds=data.dirFunds;
        this.SIPFunds=data.sipfunds;
     
     
      },
     
    (error)=>{
     this.custServ.customerError=error;
      this.router.navigate(['/errorCustomer']);
    }
    );

   
  }

}
