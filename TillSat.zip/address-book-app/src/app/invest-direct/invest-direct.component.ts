import { Component, OnInit } from '@angular/core';
import { Statement } from '../model/statement';
import { Directdata } from '../model/directdata';
import { CustomerService } from '../service/customer.service';
import { BankMutualFund } from '../model/bankmutualfund';
import { Router } from '@angular/router';

@Component({
  selector: 'app-invest-direct',
  templateUrl: './invest-direct.component.html',
  styleUrls: ['./invest-direct.component.css']
})
export class InvestDirectComponent implements OnInit {
  stmt: Statement;
  directData: Directdata;
  msg: String;
  mfList:BankMutualFund[];

  
  constructor(private custServ: CustomerService, private router:Router) {
    this.stmt = new Statement();
    this.directData = new Directdata();
   }

  ngOnInit() {
    this.custServ.viewDirPlanCust().subscribe(
      (data)=>{
        this.mfList=data;

      }
    )
  }

  investDirect(){
    console.log("Here in Invest Direct");
    console.log(this.directData);
    this.custServ.investDirectCust(this.directData).subscribe(
      (data) => {
        this.stmt = data;
        this.msg = data.msg;
        this.custServ.customerMessage=data.msg;
        if(this.stmt.bool){
          this.router.navigate(['/custDash']);
        }else{
          this.custServ.customerError=data.msg;
          this.router.navigate(['/errorCustomer']);
        }
        
      },
      (error)=>{
       this.custServ.customerError=error;
        this.router.navigate(['/errorCustomer']);
      }
    );
  }
}
