import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { UpdateMinAmtDirComponent } from './update-min-amt-dir.component';

describe('UpdateMinAmtDirComponent', () => {
  let component: UpdateMinAmtDirComponent;
  let fixture: ComponentFixture<UpdateMinAmtDirComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ UpdateMinAmtDirComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(UpdateMinAmtDirComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
