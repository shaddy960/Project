import { Injectable } from '@angular/core';
import { User } from '../model/user';
import { Observable } from 'rxjs';
import {Statement} from '../model/statement';
import { environment } from 'src/environments/environment.prod';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class AuthenticationService {
 
  user1:User;
  baseUrl: string;
  stmt:Statement;

  constructor(private http: HttpClient) { 
    this.baseUrl =`${environment.baseMwUrl}/customer/login`;
  }

  authenticate(user:User): Observable<Statement>{
    this.user1 = user;
       return this.http.post<Statement>(this.baseUrl,user);
    

  }

  authenticateUser(userId){
  
      sessionStorage.setItem('userId',userId);
     
          
  }

  isUserLoggedIn() {
    let userr = sessionStorage.getItem('userId')
    console.log(!(userr === null))
    return !(userr === null)
  }

  logOut() {
    sessionStorage.removeItem('userId')
  }
}
