import { Injectable } from '@angular/core';
import { HttpClient, HttpErrorResponse, HttpResponse } from '@angular/common/http';
import { environment } from 'src/environments/environment';
import { Observable, throwError  } from 'rxjs';
import { BankLogin } from '../model/bank-login';
import { Units } from '../model/units';
import { Output } from '../model/output';
import { BankMutualFund } from '../model/bankmutualfund';
import { User } from '../model/user';
import {catchError} from 'rxjs/operators';

@Injectable({
  providedIn: 'root'
})
export class BankServiceService {
  bankMessage:String;
  bankError:String;
  baseUrl:string;
  baseurl2:string;

  constructor(private http:HttpClient) {
    this.baseUrl =`${environment.baseMwUrl}/bank`;
    this.bankMessage="Welcome to Bank Administration Portal";
    this.bankError="Something went Wrong";
   }

   loginBank(user:User):Observable<Output>{
    return this.http.post<Output>(`${this.baseUrl}/bankLogin`,user).pipe(catchError(this.errorHandler));
  }
  updateGPrice(units:Units):Observable<Output>{
    return this.http.put<Output>(`${this.baseUrl}/updateGPrice`,units).pipe(catchError(this.errorHandler));
  }
  updateSPrice(units:Units):Observable<Output>{
    return this.http.put<Output>(`${this.baseUrl}/updateSPrice`,units).pipe(catchError(this.errorHandler));
  }
  addMf(bk:BankMutualFund):Observable<Output>{
    return this.http.post<Output>(`${this.baseUrl}/addMf`,bk).pipe(catchError(this.errorHandler));
  }
  getAllMfs():Observable<BankMutualFund[]>{

    return this.http.get<BankMutualFund[]>(`${this.baseUrl}/viewMf`).pipe(catchError(this.errorHandler));
  }

  getGoldPrice():Observable<Units>{

    return this.http.get<Units>(`${this.baseUrl}/viewGPrice`).pipe(catchError(this.errorHandler));
  }
  getSilverPrice():Observable<Units>{

    return this.http.get<Units>(`${this.baseUrl}/viewSPrice`).pipe(catchError(this.errorHandler));
  }
  updateDirStatus(out:Output):Observable<Output>{
    return this.http.put<Output>(`${this.baseUrl}/updateDirStatus`,out).pipe(catchError(this.errorHandler));
  }
  updateSipStatus(out:Output):Observable<Output>{
    return this.http.put<Output>(`${this.baseUrl}/updateSipStatus`,out).pipe(catchError(this.errorHandler));
  }
  updateDirAmt(out:Output):Observable<Output>{
    return this.http.put<Output>(`${this.baseUrl}/updateMinDirAmt`,out).pipe(catchError(this.errorHandler));
  }
  updateSipAmt(out:Output):Observable<Output>{
    return this.http.put<Output>(`${this.baseUrl}/updateMinSipAmt`,out).pipe(catchError(this.errorHandler));
  }
  updateNav(out:Output):Observable<Output>{
    return this.http.put<Output>(`${this.baseUrl}/updateNav`,out).pipe(catchError(this.errorHandler));
  }
  removeMf(out:Output):Observable<Output>{
    return this.http.patch<Output>(`${this.baseUrl}/removeMf`,out).pipe(catchError(this.errorHandler));
  }
  errorHandler(error:HttpErrorResponse){
    if (error.error instanceof ErrorEvent) {
      // A client-side or network error occurred. Handle it accordingly.
      console.error('An error occurred:', error.error);
    } else {
     
      // The backend returned an unsuccessful response code.
      // The response body may contain clues as to what went wrong,
      console.error(
        `Backend returned code ${error.status}, ` +
        `body was: ${error.error}`);
    }
    // return an observable with a user-facing error message
    return throwError(
      error.error);
  }
}
