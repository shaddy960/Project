import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-withdraw-mf',
  templateUrl: './withdraw-mf.component.html',
  styleUrls: ['./withdraw-mf.component.css']
})
export class WithdrawMFComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
