import { Component, OnInit } from '@angular/core';
import { Contact } from '../model/contact';
import { ContactService } from '../service/contact.service';

@Component({
  selector: 'app-contacts-list',
  templateUrl: './contacts-list.component.html',
  styleUrls: ['./contacts-list.component.css']
})
export class ContactsListComponent implements OnInit {

  contacts: Contact[]

  constructor(private conServ: ContactService) {
    this.contacts = [];
  }

  ngOnInit() {
    this.load();
  }

  load() {
    this.conServ.getAll().subscribe(
      (data) => {
        this.contacts = data;
      }
    );
  }

  delete(cid: number) {
    if (confirm(`Are you sure to delte contact#${cid}`)) {
      this.conServ.deleteById(cid).subscribe(
        () => {
          this.load();
        }
      );
    }
  }

}
