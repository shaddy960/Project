import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { BankServiceService } from '../service/bank-service.service';
import { BankMutualFund } from '../model/bankmutualfund';

@Component({
  selector: 'app-bank-menu',
  templateUrl: './bank-menu.component.html',
  styleUrls: ['./bank-menu.component.css']
})
export class BankMenuComponent implements OnInit {
  message:String;
  gprice:Number;
  sprice:Number;
  bankmut:BankMutualFund[];
  constructor(private router:Router,private bankService:BankServiceService) {
    this.gprice=0;
    this.sprice=0;
    this.bankmut=[];
   }

  ngOnInit() {
    this.message=this.bankService.bankMessage;
    this.getGp();
    this.getSp();
    this.getMF();
  }

  gold():void{
    this.router.navigate(['/manageGold']);
  }
  silver():void{
    this.router.navigate(['/manageSilver']);
  }
  mutualFund():void{
    this.router.navigate(['/manageMf']);
  }

  getGp(){
    this.bankService.getGoldPrice().subscribe(
      (data)=>this.gprice=data.units
    );
  }
  getSp(){
    this.bankService.getSilverPrice().subscribe(
      (data)=>this.sprice=data.units
    );
  }
  getMF(){
    this.bankService.getAllMfs().subscribe(
      (data)=>this.bankmut=data
    );
  }
}
