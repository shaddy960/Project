import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ManageGoldComponent } from './manage-gold.component';

describe('ManageGoldComponent', () => {
  let component: ManageGoldComponent;
  let fixture: ComponentFixture<ManageGoldComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ManageGoldComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ManageGoldComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
